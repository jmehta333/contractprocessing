"""
Contract Processing FastAPI Application

This application processes legal contracts to extract offshore data access restrictions
using AWS Bedrock Claude Sonnet model.
"""

from fastapi import FastAPI, HTTPException, BackgroundTasks, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import os
import logging
from typing import List, Optional
from dotenv import load_dotenv
from contextlib import asynccontextmanager
from datetime import datetime

from app.services.contract_processor import ContractProcessor
from app.services.aws_service import AWSService
from app.models.api_models import (
    ProcessingResponse, 
    StatusResponse, 
    ContractAnalysis,
    HealthResponse
)
from app.utils.logging_config import setup_logging

# Load environment variables
load_dotenv()

# Setup logging
logger = setup_logging()

# Global services
aws_service = None
contract_processor = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Startup and shutdown events"""
    global aws_service, contract_processor
    
    logger.info("Starting Contract Processing API...")
    
    # Initialize services
    try:
        aws_service = AWSService()
        contract_processor = ContractProcessor(aws_service)
        logger.info("Services initialized successfully")
    except Exception as e:
        logger.error(f"Failed to initialize services: {e}")
        raise
    
    yield
    
    logger.info("Shutting down Contract Processing API...")


# Create FastAPI app
app = FastAPI(
    title="Contract Processing API",
    description="API for processing legal contracts and extracting offshore data access restrictions",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
    lifespan=lifespan
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Configure appropriately for production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/health", response_model=HealthResponse, tags=["Health"])
async def health_check():
    """Health check endpoint"""
    try:
        # Check AWS connectivity
        aws_status = await aws_service.check_connectivity() if aws_service else False
        
        # Get PDF processor status
        pdf_status = {}
        if contract_processor and hasattr(contract_processor, 'pdf_processor'):
            try:
                pdf_status = contract_processor.pdf_processor.get_processor_status()
            except AttributeError:
                # Method doesn't exist, create basic status
                pdf_status = {
                    "pdf_direct_available": True,
                    "ocr_available": True,
                    "tesseract_working": True
                }
        
        return HealthResponse(
            status="healthy" if aws_status else "degraded",
            # Don't set timestamp - let default_factory handle it
            services={
                "aws_bedrock": aws_status,
                "file_system": os.path.exists("data/sample_contracts"),
                "processing_state": os.path.exists("data/processing_state"),
                "pdf_direct": pdf_status.get("pdf_direct_available", False),
                "ocr_available": pdf_status.get("ocr_available", False),
                "tesseract_working": pdf_status.get("tesseract_working", False)
            }
        )
    except Exception as e:
        logger.error(f"Health check failed: {e}")
        raise HTTPException(status_code=500, detail=f"Health check failed: {str(e)}")


@app.post("/process-contracts", response_model=ProcessingResponse, tags=["Processing"])
async def process_contracts(
    background_tasks: BackgroundTasks,
    use_sample_files: bool = True,
    skip_completed: bool = True  # Changed default to True
):
    """
    Process contract files to extract offshore data restrictions
    
    Args:
        use_sample_files: Whether to process files from data/sample_contracts directory
        skip_completed: Whether to skip files that have been successfully processed recently
    
    Returns:
        ProcessingResponse with job ID and status
    """
    try:
        if not contract_processor:
            raise HTTPException(status_code=500, detail="Contract processor not initialized")
        
        # Start processing in background - always using files from local directory
        job_id = await contract_processor.start_processing(
            uploaded_files=None,  # Never use uploaded files
            use_sample_files=use_sample_files,
            skip_completed=skip_completed
        )
        
        return ProcessingResponse(
            job_id=job_id,
            status="started",
            message="Contract processing started",
            total_files=0,  # Will be updated by processor
            processed_files=0
        )
        
    except Exception as e:
        logger.error(f"Failed to start contract processing: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/process-contracts", response_model=ProcessingResponse, tags=["Processing"])
async def process_contracts_get(
    background_tasks: BackgroundTasks,
    use_sample_files: bool = True,
    skip_completed: bool = True  # Changed default to True
):
    """
    Process contract files to extract offshore data restrictions (GET version for easy testing)
    
    Args:
        use_sample_files: Whether to process files from data/sample_contracts directory
        skip_completed: Whether to skip files that have been successfully processed recently
    
    Returns:
        ProcessingResponse with job ID and status
    """
    # Use the same logic as the POST endpoint
    return await process_contracts(background_tasks, use_sample_files, skip_completed)


@app.get("/status/{job_id}", response_model=StatusResponse, tags=["Processing"])
async def get_processing_status(job_id: str):
    """Get processing status for a job"""
    try:
        if not contract_processor:
            raise HTTPException(status_code=500, detail="Contract processor not initialized")
        
        status = await contract_processor.get_job_status(job_id)
        
        if not status:
            raise HTTPException(status_code=404, detail="Job not found")
        
        return status
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to get job status: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/results/{job_id}", tags=["Results"])
async def get_results(job_id: str, format: str = "json"):
    """Download processing results"""
    try:
        if not contract_processor:
            raise HTTPException(status_code=500, detail="Contract processor not initialized")
        
        results = await contract_processor.get_results(job_id, format)
        
        if not results:
            raise HTTPException(status_code=404, detail="Results not found")
        
        return results
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to get results: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/resume-processing", response_model=ProcessingResponse, tags=["Processing"])
async def resume_processing(background_tasks: BackgroundTasks):
    """Resume interrupted processing"""
    try:
        if not contract_processor:
            raise HTTPException(status_code=500, detail="Contract processor not initialized")
        
        job_id = await contract_processor.resume_processing()
        
        return ProcessingResponse(
            job_id=job_id,
            status="resumed",
            message="Processing resumed from last checkpoint",
            total_files=0,  # Will be updated by processor
            processed_files=0
        )
        
    except Exception as e:
        logger.error(f"Failed to resume processing: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/files", tags=["Files"])
async def list_available_files():
    """List available contract files"""
    try:
        files = []
        sample_dir = "data/sample_contracts"
        
        if os.path.exists(sample_dir):
            for filename in os.listdir(sample_dir):
                if filename.lower().endswith(('.pdf', '.docx')):
                    file_path = os.path.join(sample_dir, filename)
                    file_size = os.path.getsize(file_path)
                    files.append({
                        "filename": filename,
                        "size_bytes": file_size,
                        "size_mb": round(file_size / (1024 * 1024), 2)
                    })
        
        return {
            "total_files": len(files),
            "files": files
        }
        
    except Exception as e:
        logger.error(f"Failed to list files: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/test-pdf-processing", tags=["Testing"])
async def test_pdf_processing(filename: str):
    """Test PDF processing for a specific file"""
    try:
        if not contract_processor:
            raise HTTPException(status_code=500, detail="Contract processor not initialized")
        
        file_path = f"data/sample_contracts/{filename}"
        
        if not os.path.exists(file_path):
            raise HTTPException(status_code=404, detail="File not found")
        
        # Get PDF info
        pdf_info = await contract_processor.pdf_processor.get_pdf_info(file_path)
        
        # Extract text
        start_time = datetime.now()
        try:
            text = await contract_processor.pdf_processor.extract_text_from_pdf(file_path)
            extraction_time = (datetime.now() - start_time).total_seconds()
            
            return {
                "filename": filename,
                "pdf_info": pdf_info,
                "extraction_successful": True,
                "text_length": len(text),
                "text_preview": text[:500] + "..." if len(text) > 500 else text,
                "extraction_time_seconds": extraction_time,
                "processor_status": contract_processor.pdf_processor.get_processor_status()
            }
            
        except Exception as extraction_error:
            extraction_time = (datetime.now() - start_time).total_seconds()
            
            return {
                "filename": filename,
                "pdf_info": pdf_info,
                "extraction_successful": False,
                "error_message": str(extraction_error),
                "extraction_time_seconds": extraction_time,
                "processor_status": contract_processor.pdf_processor.get_processor_status()
            }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to test PDF processing: {e}")
        raise HTTPException(status_code=500, detail=str(e))


if __name__ == "__main__":
    import uvicorn
    
    port = int(os.getenv("API_PORT", 8000))
    debug = os.getenv("DEBUG", "False").lower() == "true"
    
    uvicorn.run(
        "app.main:app",
        host="0.0.0.0",
        port=port,
        reload=debug,
        log_level="info"
    )
