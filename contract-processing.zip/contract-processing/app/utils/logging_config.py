"""
Logging configuration for the contract processing application
"""

import logging
import os
import sys
from typing import Optional
from datetime import datetime
from dotenv import load_dotenv

try:
    import boto3
    from watchtower import CloudWatchLogsHandler
    CLOUDWATCH_AVAILABLE = True
except ImportError:
    CLOUDWATCH_AVAILABLE = False
    print("Warning: CloudWatch logging not available. Install watchtower for CloudWatch support.")

# Load environment variables
load_dotenv()


class CloudWatchFilter(logging.Filter):
    """Filter to add additional context to CloudWatch logs"""
    
    def filter(self, record):
        record.service = "contract-processing-api"
        record.environment = os.getenv("ENVIRONMENT", "development")
        record.timestamp = datetime.utcnow().isoformat()
        return True


def setup_logging(
    log_level: str = None,
    enable_cloudwatch: bool = None,
    log_group: str = None
) -> logging.Logger:
    """
    Setup application logging with console and CloudWatch handlers
    
    Args:
        log_level: Logging level (DEBUG, INFO, WARNING, ERROR)
        enable_cloudwatch: Whether to enable CloudWatch logging
        log_group: CloudWatch log group name
    
    Returns:
        Configured logger instance
    """
    
    # Configuration from environment
    if log_level is None:
        log_level = os.getenv("LOG_LEVEL", "INFO").upper()
    
    if enable_cloudwatch is None:
        enable_cloudwatch = os.getenv("ENABLE_CLOUDWATCH", "True").lower() == "true"
    
    if log_group is None:
        log_group = os.getenv("CLOUDWATCH_LOG_GROUP", "contract-processing-logs")
    
    log_stream = os.getenv("CLOUDWATCH_LOG_STREAM", "contract-processing-stream")
    
    # Create logger
    logger = logging.getLogger("contract_processing")
    logger.setLevel(getattr(logging, log_level, logging.INFO))
    
    # Remove existing handlers to avoid duplicates
    for handler in logger.handlers[:]:
        logger.removeHandler(handler)
    
    # Console handler with formatting
    console_handler = logging.StreamHandler(sys.stdout)
    console_formatter = logging.Formatter(
        fmt='%(asctime)s - %(name)s - %(levelname)s - [%(filename)s:%(lineno)d] - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    console_handler.setFormatter(console_formatter)
    console_handler.setLevel(getattr(logging, log_level, logging.INFO))
    logger.addHandler(console_handler)
    
    # CloudWatch handler (if available and enabled)
    if enable_cloudwatch and CLOUDWATCH_AVAILABLE:
        try:
            # Create boto3 session
            session = boto3.Session(
                aws_access_key_id=os.getenv("AWS_ACCESS_KEY_ID"),
                aws_secret_access_key=os.getenv("AWS_SECRET_ACCESS_KEY"),
                region_name=os.getenv("AWS_REGION", "us-east-1"),
                profile_name=os.getenv("AWS_PROFILE")
            )
            
            # Create CloudWatch logs client
            cloudwatch_client = session.client('logs')
            
            # Create CloudWatch handler
            cloudwatch_handler = CloudWatchLogsHandler(
                log_group=log_group,
                stream_name=log_stream,
                boto3_client=cloudwatch_client
            )
            
            # CloudWatch formatter (JSON format for structured logging)
            cloudwatch_formatter = logging.Formatter(
                fmt='{"timestamp": "%(asctime)s", "level": "%(levelname)s", "service": "%(service)s", '
                    '"environment": "%(environment)s", "logger": "%(name)s", "message": "%(message)s", '
                    '"filename": "%(filename)s", "line": %(lineno)d}',
                datefmt='%Y-%m-%dT%H:%M:%S'
            )
            
            cloudwatch_handler.setFormatter(cloudwatch_formatter)
            cloudwatch_handler.addFilter(CloudWatchFilter())
            cloudwatch_handler.setLevel(getattr(logging, log_level, logging.INFO))
            
            logger.addHandler(cloudwatch_handler)
            logger.info(f"CloudWatch logging enabled - Log Group: {log_group}, Stream: {log_stream}")
            
        except Exception as e:
            logger.warning(f"Failed to setup CloudWatch logging: {e}")
            logger.info("Continuing with console logging only")
    
    elif enable_cloudwatch and not CLOUDWATCH_AVAILABLE:
        logger.warning("CloudWatch logging requested but watchtower not available")
    
    # File handler for local development
    if os.getenv("DEBUG", "False").lower() == "true":
        try:
            os.makedirs("logs", exist_ok=True)
            file_handler = logging.FileHandler("logs/contract_processing.log")
            file_formatter = logging.Formatter(
                fmt='%(asctime)s - %(name)s - %(levelname)s - [%(filename)s:%(lineno)d] - %(message)s',
                datefmt='%Y-%m-%d %H:%M:%S'
            )
            file_handler.setFormatter(file_formatter)
            file_handler.setLevel(logging.DEBUG)
            logger.addHandler(file_handler)
        except Exception as e:
            logger.warning(f"Failed to setup file logging: {e}")
    
    # Set third-party library log levels
    logging.getLogger("boto3").setLevel(logging.WARNING)
    logging.getLogger("botocore").setLevel(logging.WARNING)
    logging.getLogger("urllib3").setLevel(logging.WARNING)
    logging.getLogger("uvicorn").setLevel(logging.INFO)
    
    logger.info(f"Logging configured - Level: {log_level}, CloudWatch: {enable_cloudwatch and CLOUDWATCH_AVAILABLE}")
    
    return logger


def get_logger(name: str) -> logging.Logger:
    """
    Get a logger instance for a specific module
    
    Args:
        name: Logger name (usually __name__)
    
    Returns:
        Logger instance
    """
    return logging.getLogger(f"contract_processing.{name}")


# Performance logging decorator
def log_performance(func):
    """Decorator to log function performance"""
    import functools
    import time
    
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        logger = get_logger(func.__module__)
        start_time = time.time()
        
        try:
            result = func(*args, **kwargs)
            execution_time = time.time() - start_time
            logger.info(f"{func.__name__} completed in {execution_time:.2f}s")
            return result
        except Exception as e:
            execution_time = time.time() - start_time
            logger.error(f"{func.__name__} failed after {execution_time:.2f}s: {e}")
            raise
    
    return wrapper


# Async performance logging decorator
def log_async_performance(func):
    """Decorator to log async function performance"""
    import functools
    import time
    import asyncio
    
    @functools.wraps(func)
    async def wrapper(*args, **kwargs):
        logger = get_logger(func.__module__)
        start_time = time.time()
        
        try:
            result = await func(*args, **kwargs)
            execution_time = time.time() - start_time
            logger.info(f"{func.__name__} completed in {execution_time:.2f}s")
            return result
        except Exception as e:
            execution_time = time.time() - start_time
            logger.error(f"{func.__name__} failed after {execution_time:.2f}s: {e}")
            raise
    
    return wrapper
