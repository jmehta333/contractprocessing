"""
Enhanced PDF text extraction with AWS Textract and PyPDF2 fallback
"""

import os
import logging
import time
import tempfile
from typing import Optional, List
from pathlib import Path
import asyncio
import json

try:
    import boto3
    from botocore.exceptions import ClientError, NoCredentialsError
    TEXTRACT_AVAILABLE = True
except ImportError:
    TEXTRACT_AVAILABLE = False

from app.utils.logging_config import get_logger, log_async_performance

logger = get_logger(__name__)


class EnhancedPDFProcessor:
    """Enhanced PDF processor with AWS Textract and PyPDF2 fallback"""
    
    def __init__(self):
        """Initialize the PDF processor"""
        self.min_content_length = 100  # Minimum text length to consider valid
        self.cache_dir = Path("data/cache")
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        
        # AWS configuration
        self.aws_profile = os.getenv("AWS_PROFILE")
        self.aws_region = os.getenv("AWS_REGION", "us-east-1")
        self.s3_bucket = os.getenv("S3_BUCKET")
        
        # Initialize AWS services
        self._setup_aws_services()
    
    def _setup_aws_services(self):
        """Initialize AWS services"""
        try:
            # Set up AWS session with profile if specified
            if self.aws_profile:
                boto3.setup_default_session(profile_name=self.aws_profile)
            
            # Initialize AWS clients
            if TEXTRACT_AVAILABLE:
                self.textract_client = boto3.client("textract", region_name=self.aws_region)
                self.s3_client = boto3.client("s3", region_name=self.aws_region)
                logger.info("✅ AWS Textract client initialized successfully")
            else:
                logger.warning("❌ Boto3 not available, Textract functionality disabled")
                self.textract_client = None
                self.s3_client = None
                
        except NoCredentialsError:
            logger.error("❌ AWS credentials not found. Textract functionality disabled.")
            self.textract_client = None
            self.s3_client = None
        except Exception as e:
            logger.error(f"❌ Failed to initialize AWS services: {e}")
            self.textract_client = None
            self.s3_client = None
    
    @log_async_performance
    async def extract_text_from_pdf(self, file_path: str) -> str:
        """
        Extract text from PDF using AWS Textract only
        
        Args:
            file_path: Path to the PDF file
        
        Returns:
            Extracted text content
        """
        file_path = Path(file_path)
        
        if not file_path.exists():
            raise FileNotFoundError(f"PDF file not found: {file_path}")
        
        logger.info(f"Processing PDF with AWS Textract: {file_path.name}")
        
        # Use AWS Textract for all PDF text extraction
        if self.textract_client and self.s3_client:
            try:
                text = await self._extract_text_with_textract(file_path)
                
                if text and len(text.strip()) >= self.min_content_length:
                    logger.info(f"Successfully extracted {len(text)} characters using AWS Textract")
                    return text
                else:
                    logger.warning(f"Textract extraction yielded insufficient content ({len(text) if text else 0} chars)")
                    raise ValueError(f"Insufficient text extracted from PDF: {file_path.name}")
            
            except Exception as e:
                logger.error(f"AWS Textract extraction failed: {e}")
                raise
        
        else:
            raise RuntimeError("AWS Textract not available - cannot process PDF files")
    
    async def _extract_text_with_textract(self, file_path: Path) -> str:
        """Extract text using AWS Textract"""
        if not self.textract_client or not self.s3_client:
            raise RuntimeError("AWS Textract not available")
        
        logger.info(f"Processing with AWS Textract: {file_path.name}")
        
        # Upload PDF to S3 temporarily if needed
        s3_key = None
        output_key = None
        try:
            if self.s3_bucket:
                # Upload to S3 for Textract processing in textract folder
                timestamp = int(time.time())
                s3_key = f"textract/temp/{file_path.stem}-{timestamp}.pdf"
                # Use consistent naming for output that matches our checking logic
                output_key = f"textract/output/{file_path.stem}_textract.json"
                
                await self._upload_to_s3(file_path, s3_key)
                
                # Process with Textract using S3
                text = await self._process_with_textract_s3(s3_key, output_key)
            else:
                # Process directly with synchronous Textract (smaller files)
                text = await self._process_with_textract_direct(file_path)
            
            return text
            
        finally:
            # Clean up temporary S3 file (keep output for reference)
            if s3_key and self.s3_bucket:
                try:
                    self.s3_client.delete_object(Bucket=self.s3_bucket, Key=s3_key)
                    logger.debug(f"Cleaned up temporary S3 file: {s3_key}")
                except Exception as e:
                    logger.warning(f"Failed to clean up S3 file {s3_key}: {e}")
    
    async def _upload_to_s3(self, file_path: Path, s3_key: str):
        """Upload file to S3"""
        loop = asyncio.get_event_loop()
        
        await loop.run_in_executor(
            None,
            lambda: self.s3_client.upload_file(str(file_path), self.s3_bucket, s3_key)
        )
        logger.debug(f"Uploaded {file_path.name} to S3: {s3_key}")
    
    async def _process_with_textract_s3(self, s3_key: str, output_key: str) -> str:
        """Process PDF using Textract with S3 (for large files) with detailed progress reporting"""
        logger.info(f"🚀 Starting Textract processing for S3 key: {s3_key}")
        
        # Start Textract job
        loop = asyncio.get_event_loop()
        start_time = time.time()
        
        logger.info("📤 Submitting Textract job...")
        response = await loop.run_in_executor(
            None,
            lambda: self.textract_client.start_document_text_detection(
                DocumentLocation={
                    "S3Object": {
                        "Bucket": self.s3_bucket,
                        "Name": s3_key
                    }
                }
            )
        )
        
        job_id = response["JobId"]
        submit_time = time.time() - start_time
        logger.info(f"✅ Textract job submitted successfully: {job_id} (Submit time: {submit_time:.1f}s)")
        
        # Poll for completion with enhanced progress reporting
        logger.info("🔄 Monitoring job progress...")
        status = await self._wait_for_textract_job(job_id)
        
        if status != "SUCCEEDED":
            error_msg = f"Textract job failed with status: {status}"
            logger.error(f"❌ {error_msg}")
            raise ValueError(error_msg)
        
        # Get results with detailed progress reporting
        logger.info("📥 Retrieving Textract results...")
        text, full_response = await self._get_textract_results(job_id)
        
        # Save full Textract response to S3 for reference
        logger.info("💾 Saving Textract output to S3...")
        await self._save_textract_output(output_key, full_response, text)
        
        total_time = time.time() - start_time
        logger.info(f"🎉 Textract processing completed successfully! Total time: {total_time:.1f}s")
        logger.info(f"📝 Text extracted: {len(text)} characters from {full_response.get('LineCount', 0)} lines")
        
        return text
    
    async def _process_with_textract_direct(self, file_path: Path) -> str:
        """Process PDF using synchronous Textract (for smaller files) with progress reporting"""
        logger.info(f"🚀 Processing with synchronous Textract: {file_path.name}")
        
        with open(file_path, 'rb') as file:
            pdf_bytes = file.read()
        
        file_size_mb = len(pdf_bytes) / (1024 * 1024)
        logger.info(f"📄 File size: {file_size_mb:.2f} MB")
        
        # Check file size (max 10MB for synchronous processing)
        if len(pdf_bytes) > 10 * 1024 * 1024:
            raise ValueError(f"File too large for direct Textract processing: {file_size_mb:.2f} MB (max 10 MB)")
        
        loop = asyncio.get_event_loop()
        start_time = time.time()
        
        logger.info("📤 Submitting direct Textract request...")
        response = await loop.run_in_executor(
            None,
            lambda: self.textract_client.detect_document_text(
                Document={"Bytes": pdf_bytes}
            )
        )
        
        # Extract text from response
        text_lines = []
        total_blocks = len(response.get("Blocks", []))
        
        for block in response.get("Blocks", []):
            if block["BlockType"] == "LINE":
                text_lines.append(block["Text"])
        
        processing_time = time.time() - start_time
        logger.info(f"✅ Direct Textract completed! Time: {processing_time:.1f}s")
        logger.info(f"📊 Results: {total_blocks} blocks, {len(text_lines)} text lines")
        logger.info(f"📝 Text extracted: {len('\n'.join(text_lines))} characters")
        
        if len(text_lines) == 0:
            logger.warning("⚠️ No text lines extracted from document")
        elif len(text_lines) < 5:
            logger.warning(f"⚠️ Very few text lines extracted ({len(text_lines)}) - document might be mostly images")
        
        return "\n".join(text_lines)
    
    async def _wait_for_textract_job(self, job_id: str) -> str:
        """Poll Textract job until completion with detailed progress reporting"""
        loop = asyncio.get_event_loop()
        
        logger.info(f"📋 Starting to monitor Textract job: {job_id}")
        
        # Initial delay to let job start
        await asyncio.sleep(1)
        
        poll_count = 0
        start_time = time.time()
        
        while True:
            poll_count += 1
            
            response = await loop.run_in_executor(
                None,
                lambda: self.textract_client.get_document_text_detection(JobId=job_id)
            )
            
            status = response["JobStatus"]
            elapsed_time = time.time() - start_time
            
            # Enhanced status reporting
            if status == "IN_PROGRESS":
                logger.info(f"🔄 Textract job {job_id} status: {status} (Poll #{poll_count}, Elapsed: {elapsed_time:.1f}s)")
                
                # Add progress details if available
                if "StatusMessage" in response:
                    logger.info(f"📝 Status message: {response['StatusMessage']}")
                    
                # Show warnings if job is taking too long
                if elapsed_time > 60:  # More than 1 minute
                    logger.warning(f"⏰ Textract job taking longer than expected: {elapsed_time:.1f}s")
                elif elapsed_time > 300:  # More than 5 minutes
                    logger.error(f"🚨 Textract job taking very long: {elapsed_time:.1f}s - consider checking AWS console")
                    
            elif status == "SUCCEEDED":
                logger.info(f"✅ Textract job {job_id} completed successfully! (Elapsed: {elapsed_time:.1f}s, Polls: {poll_count})")
                
                # Log additional success details
                if "DocumentMetadata" in response:
                    pages = response["DocumentMetadata"].get("Pages", 0)
                    logger.info(f"📄 Document processed: {pages} pages")
                    
            elif status == "FAILED":
                logger.error(f"❌ Textract job {job_id} failed! (Elapsed: {elapsed_time:.1f}s)")
                if "StatusMessage" in response:
                    logger.error(f"💥 Failure reason: {response['StatusMessage']}")
                    
            elif status == "PARTIAL_SUCCESS":
                logger.warning(f"⚠️ Textract job {job_id} completed with partial success (Elapsed: {elapsed_time:.1f}s)")
                if "StatusMessage" in response:
                    logger.warning(f"📝 Status message: {response['StatusMessage']}")
            
            # Check if job is complete
            if status in ["SUCCEEDED", "FAILED", "PARTIAL_SUCCESS"]:
                return status
            
            # Wait before next poll - adaptive polling interval
            if elapsed_time < 30:
                wait_time = 2  # Poll every 2 seconds for first 30 seconds
            elif elapsed_time < 120:
                wait_time = 5  # Poll every 5 seconds for next 90 seconds
            else:
                wait_time = 10  # Poll every 10 seconds after 2 minutes
                
            logger.debug(f"⏳ Waiting {wait_time}s before next status check...")
            await asyncio.sleep(wait_time)
    
    async def _get_textract_results(self, job_id: str) -> tuple[str, dict]:
        """Collect all pages of results from a Textract job with detailed progress reporting"""
        loop = asyncio.get_event_loop()
        text_lines = []
        all_blocks = []
        next_token = None
        page_count = 0
        start_time = time.time()
        
        logger.info(f"📥 Starting to collect Textract results for job: {job_id}")
        
        # Initial delay to ensure results are ready
        await asyncio.sleep(1)
        
        while True:
            page_count += 1
            
            # Get results page
            kwargs = {"JobId": job_id}
            if next_token:
                kwargs["NextToken"] = next_token
            
            logger.info(f"📋 Fetching result page {page_count}...")
            
            response = await loop.run_in_executor(
                None,
                lambda: self.textract_client.get_document_text_detection(**kwargs)
            )
            
            # Extract text from this page and collect blocks
            blocks = response.get("Blocks", [])
            all_blocks.extend(blocks)
            
            lines_in_page = 0
            for block in blocks:
                if block["BlockType"] == "LINE":
                    text_lines.append(block["Text"])
                    lines_in_page += 1
            
            logger.info(f"✅ Result page {page_count} received: {len(blocks)} blocks, {lines_in_page} text lines")
            
            # Check for more pages
            next_token = response.get("NextToken")
            if not next_token:
                break
                
            # Brief pause between page requests
            await asyncio.sleep(0.5)
        
        elapsed_time = time.time() - start_time
        total_lines = len(text_lines)
        total_blocks = len(all_blocks)
        
        logger.info(f"🎉 Textract results collection complete!")
        logger.info(f"📊 Summary: {page_count} result pages, {total_blocks} blocks, {total_lines} text lines")
        logger.info(f"⏱️ Collection time: {elapsed_time:.1f}s")
        
        if total_lines == 0:
            logger.warning("⚠️ No text lines extracted from Textract results")
        elif total_lines < 10:
            logger.warning(f"⚠️ Very few text lines extracted ({total_lines}) - document might be mostly images/graphics")
        else:
            logger.info(f"✅ Good text extraction: {total_lines} lines of text found")
        
        # Create comprehensive response object
        full_response = {
            "JobId": job_id,
            "JobStatus": "SUCCEEDED",
            "TotalBlocks": total_blocks,
            "TotalPages": page_count,
            "Blocks": all_blocks,
            "ExtractedText": "\n".join(text_lines),
            "LineCount": total_lines,
            "ProcessingTimeSeconds": elapsed_time
        }
        
        return "\n".join(text_lines), full_response
    
    async def _save_textract_output(self, output_key: str, full_response: dict, extracted_text: str):
        """Save Textract output to S3 for reference"""
        try:
            loop = asyncio.get_event_loop()
            
            # Save full JSON response
            json_content = json.dumps(full_response, indent=2, default=str)
            await loop.run_in_executor(
                None,
                lambda: self.s3_client.put_object(
                    Bucket=self.s3_bucket,
                    Key=output_key,
                    Body=json_content,
                    ContentType='application/json'
                )
            )
            
            # Also save just the extracted text
            text_key = output_key.replace('.json', '.txt')
            await loop.run_in_executor(
                None,
                lambda: self.s3_client.put_object(
                    Bucket=self.s3_bucket,
                    Key=text_key,
                    Body=extracted_text,
                    ContentType='text/plain'
                )
            )
            
            logger.info(f"Saved Textract output to S3: {output_key} and {text_key}")
            
        except Exception as e:
            logger.warning(f"Failed to save Textract output to S3: {e}")
            # Don't fail the main process if saving fails
    
    async def get_pdf_info(self, file_path: str) -> dict:
        """Get PDF metadata and information"""
        file_path = Path(file_path)
        
        if not file_path.exists():
            raise FileNotFoundError(f"PDF file not found: {file_path}")
        
        info = {
            "filename": file_path.name,
            "size_bytes": file_path.stat().st_size,
            "size_mb": round(file_path.stat().st_size / (1024 * 1024), 2)
        }
        
        # Basic file info only - Textract will handle the content extraction
        logger.info(f"PDF info for {file_path.name}: {info['size_mb']} MB")
        
        return info
    
    def get_processor_status(self) -> dict:
        """Get status of available processing methods"""
        return {
            "textract_only": True,
            "textract_available": TEXTRACT_AVAILABLE and self.textract_client is not None,
            "s3_bucket_configured": bool(self.s3_bucket),
            "aws_profile": self.aws_profile,
            "aws_region": self.aws_region,
            "min_content_length": self.min_content_length
        }
