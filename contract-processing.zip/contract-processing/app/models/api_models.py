"""
Pydantic models for API requests and responses
"""

from pydantic import BaseModel, Field
from typing import List, Dict, Optional, Any, Union
from datetime import datetime
from enum import Enum


class ProcessingStatus(str, Enum):
    """Processing status enumeration"""
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"
    STARTED = "started"
    RESUMED = "resumed"


class RestrictionType(str, Enum):
    """Offshore restriction types"""
    PROHIBITION = "prohibition"
    NOTIFICATION_REQUIRED = "notification_required"
    CONSENT_REQUIRED = "consent_required"
    CONDITIONAL = "conditional"
    AUTHORIZED_LOCATIONS = "authorized_locations"


class DataOwnership(str, Enum):
    """Data ownership types"""
    RADIAN_DATA = "radian_data"
    COUNTERPARTY_DATA = "counterparty_data"
    BOTH = "both"
    UNCLEAR = "unclear"


class OffshoreDataProvision(BaseModel):
    """Offshore data provision details"""
    hasRestriction: bool = Field(..., description="Whether offshore restriction exists")
    section: Optional[str] = Field(None, description="Section where restriction is found")
    restrictionText: Optional[str] = Field(None, description="Exact text of restriction clause")
    restrictionType: Optional[RestrictionType] = Field(None, description="Type of restriction")
    notificationPeriod: Optional[str] = Field(None, description="Required notification period")
    geographicScope: Optional[str] = Field(None, description="Geographic scope of restriction")
    authorizedLocations: Optional[List[str]] = Field(default_factory=list, description="Authorized offshore locations")
    exceptions: Optional[str] = Field(None, description="Exceptions mentioned in clause")


class DataSubject(BaseModel):
    """Data subject details"""
    restrictionAppliesTo: Optional[DataOwnership] = Field(None, description="Who the restriction applies to")
    dataTypes: Optional[List[str]] = Field(default_factory=list, description="Types of data covered")
    clarificationNote: Optional[str] = Field(None, description="Additional clarification notes")


class RestrictionDirection(BaseModel):
    """Restriction direction details"""
    whoIsRestricted: Optional[str] = Field(None, description="Who is restricted")
    restrictedActivities: Optional[List[str]] = Field(default_factory=list, description="Restricted activities")
    requiresApprovalFrom: Optional[str] = Field(None, description="Who approval is needed from")


class ComplianceRequirements(BaseModel):
    """Compliance requirements"""
    priorConsentRequired: Optional[bool] = Field(None, description="Prior consent required")
    notificationRequired: Optional[bool] = Field(None, description="Notification required")
    attestationRequired: Optional[bool] = Field(None, description="Attestation required")
    riskAssessmentRequired: Optional[bool] = Field(None, description="Risk assessment required")
    ongoingObligations: Optional[str] = Field(None, description="Ongoing compliance obligations")


class AnalysisNotes(BaseModel):
    """Analysis notes and findings"""
    clarity: Optional[str] = Field(None, description="Clarity of the restriction")
    findings: Optional[str] = Field(None, description="Key observations")
    ambiguities: Optional[str] = Field(None, description="Unclear aspects")
    recommendations: Optional[str] = Field(None, description="Recommendations")


class ContractAnalysis(BaseModel):
    """Complete contract analysis result"""
    counterparty: Optional[str] = Field(None, description="Name of counterparty")
    contractTitle: Optional[str] = Field(None, description="Title of the contract")
    contractDate: Optional[str] = Field(None, description="Date of the contract")
    offshoreDataProvision: Optional[OffshoreDataProvision] = Field(None, description="Offshore data provision details")
    dataSubject: Optional[DataSubject] = Field(None, description="Data subject details")
    restrictionDirection: Optional[RestrictionDirection] = Field(None, description="Restriction direction")
    complianceRequirements: Optional[ComplianceRequirements] = Field(None, description="Compliance requirements")
    analysisNotes: Optional[AnalysisNotes] = Field(None, description="Analysis notes")


class ProcessingResponse(BaseModel):
    """Response for processing requests"""
    job_id: str = Field(..., description="Unique job identifier")
    status: ProcessingStatus = Field(..., description="Current processing status")
    message: str = Field(..., description="Status message")
    total_files: int = Field(..., description="Total number of files to process")
    processed_files: int = Field(..., description="Number of files processed")
    timestamp: datetime = Field(default_factory=datetime.now, description="Response timestamp")


class FileProcessingResult(BaseModel):
    """Result for individual file processing"""
    filename: str = Field(..., description="Name of the processed file")
    status: ProcessingStatus = Field(..., description="Processing status")
    analysis: Optional[ContractAnalysis] = Field(None, description="Contract analysis result")
    error_message: Optional[str] = Field(None, description="Error message if processing failed")
    processing_time_seconds: Optional[float] = Field(None, description="Time taken to process")
    timestamp: datetime = Field(default_factory=datetime.now, description="Processing timestamp")


class StatusResponse(BaseModel):
    """Status response for job tracking"""
    job_id: str = Field(..., description="Job identifier")
    status: ProcessingStatus = Field(..., description="Current status")
    total_files: int = Field(..., description="Total files in job")
    processed_files: int = Field(..., description="Files completed")
    failed_files: int = Field(default=0, description="Files that failed")
    current_file: Optional[str] = Field(None, description="Currently processing file")
    results: Optional[List[FileProcessingResult]] = Field(default_factory=list, description="Processing results")
    estimated_completion: Optional[datetime] = Field(None, description="Estimated completion time")
    started_at: Optional[datetime] = Field(None, description="Job start time")
    completed_at: Optional[datetime] = Field(None, description="Job completion time")
    error_message: Optional[str] = Field(None, description="Job-level error message")


class HealthResponse(BaseModel):
    """Health check response"""
    status: str = Field(..., description="Overall health status")
    timestamp: datetime = Field(default_factory=datetime.now, description="Health check timestamp")
    services: Dict[str, bool] = Field(..., description="Status of individual services")


class FileInfo(BaseModel):
    """File information"""
    filename: str = Field(..., description="File name")
    size_bytes: int = Field(..., description="File size in bytes")
    size_mb: float = Field(..., description="File size in MB")
    last_modified: Optional[datetime] = Field(None, description="Last modification time")


class FileListResponse(BaseModel):
    """Response for file listing"""
    total_files: int = Field(..., description="Total number of files")
    files: List[FileInfo] = Field(..., description="List of available files")


class ErrorResponse(BaseModel):
    """Error response model"""
    error: str = Field(..., description="Error type")
    message: str = Field(..., description="Error message")
    details: Optional[Dict[str, Any]] = Field(None, description="Additional error details")
    timestamp: datetime = Field(default_factory=datetime.now, description="Error timestamp")
