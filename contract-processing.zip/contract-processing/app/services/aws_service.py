"""
AWS Service for Bedrock and CloudWatch integration
"""

import json
import os
import time
import asyncio
from typing import Dict, Any, Optional
from pathlib import Path
from dotenv import load_dotenv

try:
    import boto3
    from botocore.exceptions import ClientError, NoCredentialsError
    BOTO3_AVAILABLE = True
except ImportError:
    BOTO3_AVAILABLE = False

from app.utils.logging_config import get_logger, log_async_performance

load_dotenv()
logger = get_logger(__name__)


class AWSService:
    """Service for AWS Bedrock and other AWS integrations"""
    
    def __init__(self):
        """Initialize AWS service with Bedrock client"""
        self.region = os.getenv("AWS_REGION", "us-east-1")
        self.model_id = os.getenv("BEDROCK_MODEL_ID", "anthropic.claude-3-5-sonnet-20240620-v1:0")
        self.max_tokens = int(os.getenv("MAX_TOKENS", "4096"))
        self.temperature = float(os.getenv("TEMPERATURE", "0.1"))
        
        self.bedrock_client = None
        self.cloudwatch_client = None
        
        if not BOTO3_AVAILABLE:
            logger.error("boto3 not available. AWS services will not work.")
            return
        
        try:
            # Create session
            self.session = self._create_session()
            
            # Initialize Bedrock client
            self.bedrock_client = self.session.client(
                service_name='bedrock-runtime',
                region_name=self.region
            )
            
            # Initialize S3 client for storing outputs
            self.s3_client = self.session.client(
                service_name='s3',
                region_name=self.region
            )
            self.s3_bucket = os.getenv("S3_BUCKET")
            
            # Initialize CloudWatch client
            self.cloudwatch_client = self.session.client(
                service_name='logs',
                region_name=self.region
            )
            
            logger.info(f"AWS services initialized - Region: {self.region}, Model: {self.model_id}")
            
        except Exception as e:
            logger.error(f"Failed to initialize AWS services: {e}")
            raise
    
    def _create_session(self) -> 'boto3.Session':
        """Create boto3 session with appropriate credentials"""
        
        # Try different credential methods
        aws_profile = os.getenv("AWS_PROFILE")
        aws_access_key = os.getenv("AWS_ACCESS_KEY_ID")
        aws_secret_key = os.getenv("AWS_SECRET_ACCESS_KEY")
        
        if aws_profile:
            logger.info(f"Using AWS profile: {aws_profile}")
            return boto3.Session(profile_name=aws_profile, region_name=self.region)
        
        elif aws_access_key and aws_secret_key:
            logger.info("Using AWS access keys from environment")
            return boto3.Session(
                aws_access_key_id=aws_access_key,
                aws_secret_access_key=aws_secret_key,
                region_name=self.region
            )
        
        else:
            logger.info("Using default AWS credentials (IAM role/default profile)")
            return boto3.Session(region_name=self.region)
    
    async def check_connectivity(self) -> bool:
        """Check AWS connectivity"""
        if not self.bedrock_client:
            return False
        
        try:
            # Test Bedrock Runtime connectivity with a minimal request
            loop = asyncio.get_event_loop()
            
            # Create a minimal test request
            test_payload = {
                "anthropic_version": "bedrock-2023-05-31",
                "max_tokens": 10,
                "messages": [
                    {
                        "role": "user",
                        "content": "Test"
                    }
                ]
            }
            
            await loop.run_in_executor(
                None,
                lambda: self.bedrock_client.invoke_model(
                    modelId=self.model_id,
                    body=json.dumps(test_payload)
                )
            )
            return True
        except Exception as e:
            logger.warning(f"AWS connectivity check failed: {e}")
            # Don't fail completely - might be permissions issue
            return True
    
    @log_async_performance
    async def analyze_contract(self, contract_text: str, prompt_text: str) -> Dict[str, Any]:
        """
        Analyze contract using Claude Sonnet model
        
        Args:
            contract_text: The contract content to analyze
            prompt_text: The analysis prompt instructions
        
        Returns:
            Analysis result as dictionary
        """
        if not self.bedrock_client:
            raise RuntimeError("Bedrock client not available")
        
        try:
            # Prepare the request
            full_prompt = f"{prompt_text}\n\nCONTRACT DOCUMENT:\n{contract_text}"
            
            # Prepare request body for Claude
            request_body = {
                "anthropic_version": "bedrock-2023-05-31",
                "max_tokens": self.max_tokens,
                "temperature": self.temperature,
                "messages": [
                    {
                        "role": "user",
                        "content": full_prompt
                    }
                ]
            }
            
            logger.info(f"Sending request to Bedrock model: {self.model_id}")
            logger.debug(f"Request body: {json.dumps(request_body, indent=2)}")
            
            # Make async request to Bedrock
            loop = asyncio.get_event_loop()
            response = await loop.run_in_executor(
                None,
                lambda: self.bedrock_client.invoke_model(
                    modelId=self.model_id,
                    body=json.dumps(request_body),
                    contentType="application/json",
                    accept="application/json"
                )
            )
            
            # Parse response
            response_body = json.loads(response['body'].read().decode('utf-8'))
            
            logger.debug(f"Bedrock response: {json.dumps(response_body, indent=2)}")
            
            # Extract content from Claude response
            if 'content' in response_body and len(response_body['content']) > 0:
                content = response_body['content'][0]['text']
                
                # Try to parse as JSON
                try:
                    # Extract JSON from response if it's wrapped in markdown or other text
                    json_start = content.find('{')
                    json_end = content.rfind('}') + 1
                    
                    if json_start >= 0 and json_end > json_start:
                        json_content = content[json_start:json_end]
                        analysis_result = json.loads(json_content)
                        
                        logger.info("Successfully parsed JSON response from Claude")
                        return analysis_result
                    
                    else:
                        logger.warning("No JSON found in Claude response")
                        return {"error": "No JSON found in response", "raw_response": content}
                
                except json.JSONDecodeError as e:
                    logger.warning(f"Failed to parse JSON from Claude response: {e}")
                    return {"error": "Invalid JSON in response", "raw_response": content}
            
            else:
                logger.error("No content in Bedrock response")
                return {"error": "No content in response", "response": response_body}
        
        except ClientError as e:
            error_code = e.response['Error']['Code']
            error_message = e.response['Error']['Message']
            logger.error(f"Bedrock API error [{error_code}]: {error_message}")
            
            if error_code == "ThrottlingException":
                raise RuntimeError("Rate limit exceeded. Please try again later.")
            elif error_code == "ValidationException":
                raise RuntimeError(f"Invalid request: {error_message}")
            else:
                raise RuntimeError(f"Bedrock API error: {error_message}")
        
        except Exception as e:
            logger.error(f"Unexpected error calling Bedrock: {e}")
            raise RuntimeError(f"Failed to analyze contract: {e}")
    
    async def log_to_cloudwatch(
        self,
        log_group: str,
        log_stream: str,
        message: str,
        level: str = "INFO"
    ) -> bool:
        """
        Log message to CloudWatch (fallback method)
        
        Args:
            log_group: CloudWatch log group name
            log_stream: CloudWatch log stream name
            message: Message to log
            level: Log level
        
        Returns:
            Success status
        """
        if not self.cloudwatch_client:
            return False
        
        try:
            import time
            
            # Prepare log event
            log_event = {
                'timestamp': int(time.time() * 1000),
                'message': f"[{level}] {message}"
            }
            
            # Send to CloudWatch
            loop = asyncio.get_event_loop()
            await loop.run_in_executor(
                None,
                lambda: self.cloudwatch_client.put_log_events(
                    logGroupName=log_group,
                    logStreamName=log_stream,
                    logEvents=[log_event]
                )
            )
            
            return True
            
        except Exception as e:
            logger.error(f"Failed to log to CloudWatch: {e}")
            return False
    
    def get_model_info(self) -> Dict[str, Any]:
        """Get information about the configured model"""
        return {
            "model_id": self.model_id,
            "max_tokens": self.max_tokens,
            "temperature": self.temperature,
            "region": self.region,
            "available": self.bedrock_client is not None
        }
    
    @log_async_performance
    async def save_llm_output_to_s3(self, base_filename: str, llm_response: Dict[str, Any]) -> Optional[str]:
        """
        Save LLM output to S3 bucket in llm folder
        
        Args:
            base_filename: Contract filename without extension (already processed with Path().stem)
            llm_response: The complete LLM response including analysis
            
        Returns:
            S3 key where the output was saved, or None if failed
        """
        if not self.s3_client or not self.s3_bucket:
            logger.warning("S3 not available for storing LLM output")
            return None
        
        try:
            import time
            from pathlib import Path
            
            # Generate S3 key in llm folder
            # Note: base_filename here is already the stem (base filename without extension)
            file_stem = base_filename  # Don't apply Path().stem again!
            timestamp = int(time.time())
            s3_key = f"llm/output/{file_stem}-{timestamp}.json"
            logger.info(f"DEBUG AWS: Saving LLM output - base_filename='{base_filename}', file_stem='{file_stem}', s3_key='{s3_key}'")
            
            # Prepare the output data
            output_data = {
                "filename": base_filename,  # Store the base filename
                "timestamp": timestamp,
                "timestamp": timestamp,
                "llm_response": llm_response,
                "model_id": self.model_id,
                "processing_metadata": {
                    "max_tokens": self.max_tokens,
                    "temperature": self.temperature,
                    "region": self.region
                }
            }
            
            # Convert to JSON
            json_output = json.dumps(output_data, indent=2, default=str)
            
            # Upload to S3
            loop = asyncio.get_event_loop()
            await loop.run_in_executor(
                None,
                lambda: self.s3_client.put_object(
                    Bucket=self.s3_bucket,
                    Key=s3_key,
                    Body=json_output.encode('utf-8'),
                    ContentType='application/json'
                )
            )
            
            logger.info(f"LLM output saved to S3: {s3_key}")
            return s3_key
            
        except Exception as e:
            logger.error(f"Failed to save LLM output to S3: {e}")
            return None
    
    @log_async_performance
    async def load_llm_output_from_s3(self, s3_key: str) -> Optional[Dict[str, Any]]:
        """
        Load LLM output from S3
        
        Args:
            s3_key: S3 key where the output is stored
            
        Returns:
            The LLM output data, or None if failed
        """
        if not self.s3_client or not self.s3_bucket:
            logger.warning("S3 not available for loading LLM output")
            return None
        
        try:
            loop = asyncio.get_event_loop()
            response = await loop.run_in_executor(
                None,
                lambda: self.s3_client.get_object(
                    Bucket=self.s3_bucket,
                    Key=s3_key
                )
            )
            
            content = response['Body'].read().decode('utf-8')
            return json.loads(content)
            
        except Exception as e:
            logger.error(f"Failed to load LLM output from S3: {e}")
            return None

    async def check_s3_object_exists(self, s3_key: str) -> bool:
        """
        Check if an S3 object exists
        
        Args:
            s3_key: S3 key to check
            
        Returns:
            True if object exists, False otherwise
        """
        if not self.s3_client:
            return False
        
        try:
            loop = asyncio.get_event_loop()
            await loop.run_in_executor(
                None,
                lambda: self.s3_client.head_object(Bucket=self.s3_bucket, Key=s3_key)
            )
            return True
        except ClientError as e:
            if e.response['Error']['Code'] == '404':
                return False
            else:
                logger.warning(f"Error checking S3 object {s3_key}: {e}")
                return False
        except Exception as e:
            logger.warning(f"Error checking S3 object {s3_key}: {e}")
            return False

    async def check_textract_output_exists(self, filename: str) -> bool:
        """
        Check if Textract output exists for a given filename
        
        Args:
            filename: Original filename (with or without extension)
            
        Returns:
            True if Textract output exists, False otherwise
        """
        base_filename = Path(filename).stem
        
        # Check for JSON file (primary output)
        json_key = f"textract/output/{base_filename}_textract.json"
        exists = await self.check_s3_object_exists(json_key)
        
        if exists:
            logger.debug(f"✅ Found existing Textract output: {json_key}")
        else:
            logger.debug(f"❌ No Textract output found for: {base_filename}")
            
        return exists

    async def check_llm_output_exists(self, filename: str) -> bool:
        """
        Check if LLM analysis output exists for a given filename
        
        Args:
            filename: Original filename (with or without extension)
            
        Returns:
            True if LLM output exists, False otherwise
        """
        if not self.s3_client:
            return False
            
        try:
            base_filename = Path(filename).stem
            logger.info(f"DEBUG AWS: Checking LLM existence for filename='{filename}', base_filename='{base_filename}'")
            
            # List objects in LLM directory with this filename prefix
            loop = asyncio.get_event_loop()
            response = await loop.run_in_executor(
                None,
                lambda: self.s3_client.list_objects_v2(
                    Bucket=self.s3_bucket,
                    Prefix=f"llm/output/{base_filename}",
                    MaxKeys=10
                )
            )
            
            # Check if any objects exist with the expected naming pattern
            objects = response.get('Contents', [])
            logger.info(f"DEBUG AWS: Found {len(objects)} objects with prefix 'llm/output/{base_filename}'")
            for obj in objects:
                key = obj['Key']
                logger.info(f"DEBUG AWS: Checking object: {key}")
                # Pattern: llm/output/{base_filename}-{timestamp}.json
                expected_prefix = f"llm/output/{base_filename}-"
                if key.startswith(expected_prefix) and key.endswith('.json'):
                    # Verify the middle part is a valid timestamp (digits only)
                    middle_part = key[len(expected_prefix):-5]  # Remove .json suffix
                    if middle_part.isdigit():
                        logger.info(f"DEBUG AWS: Found matching LLM output: {key}")
                        return True
                    else:
                        logger.info(f"DEBUG AWS: Object {key} has non-numeric timestamp: {middle_part}")
                else:
                    logger.info(f"DEBUG AWS: Object {key} does not match pattern {expected_prefix}*.json")
            
            logger.info(f"DEBUG AWS: No LLM output found for: {base_filename}")
            return False
            
        except Exception as e:
            logger.warning(f"Error checking LLM output for {filename}: {e}")
            return False

    async def get_textract_output_from_s3(self, filename: str) -> Optional[str]:
        """
        Retrieve existing Textract output from S3
        
        Args:
            filename: Original filename
            
        Returns:
            Extracted text content or None if not found
        """
        if not self.s3_client:
            return None
            
        try:
            base_filename = Path(filename).stem
            
            # Try to get the text file first (simpler format)
            text_key = f"textract/output/{base_filename}_textract.txt"
            
            if await self.check_s3_object_exists(text_key):
                loop = asyncio.get_event_loop()
                response = await loop.run_in_executor(
                    None,
                    lambda: self.s3_client.get_object(Bucket=self.s3_bucket, Key=text_key)
                )
                content = response['Body'].read().decode('utf-8')
                logger.info(f"📥 Retrieved Textract output from S3: {text_key}")
                return content
                
            return None
            
        except Exception as e:
            logger.warning(f"Error retrieving Textract output for {filename}: {e}")
            return None

    async def get_llm_output_from_s3(self, filename: str) -> Optional[Dict[str, Any]]:
        """
        Retrieve existing LLM analysis output from S3
        
        Args:
            filename: Original filename
            
        Returns:
            LLM analysis result or None if not found
        """
        if not self.s3_client:
            return None
            
        try:
            base_filename = Path(filename).stem
            
            # First, find the actual file by listing objects with the prefix
            loop = asyncio.get_event_loop()
            response = await loop.run_in_executor(
                None,
                lambda: self.s3_client.list_objects_v2(
                    Bucket=self.s3_bucket,
                    Prefix=f"llm/output/{base_filename}-",
                    MaxKeys=10
                )
            )
            
            # Find the JSON file
            objects = response.get('Contents', [])
            json_key = None
            for obj in objects:
                if obj['Key'].endswith('.json'):
                    json_key = obj['Key']
                    break
            
            if json_key:
                # Retrieve the file content
                response = await loop.run_in_executor(
                    None,
                    lambda: self.s3_client.get_object(Bucket=self.s3_bucket, Key=json_key)
                )
                content = response['Body'].read().decode('utf-8')
                full_data = json.loads(content)
                
                # Extract the LLM response from the stored structure
                analysis_result = full_data.get('llm_response', full_data)
                logger.info(f"📥 Retrieved LLM analysis from S3: {json_key}")
                return analysis_result
                
            logger.debug(f"❌ No LLM output file found for: {base_filename}")
            return None
            
        except Exception as e:
            logger.warning(f"Error retrieving LLM output for {filename}: {e}")
            return None
