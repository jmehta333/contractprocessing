"""
Contract processing service for handling document analysis workflow
"""

import os
import json
import uuid
import asyncio
from typing import List, Optional, Dict, Any
from datetime import datetime, timedelta, timedelta
from pathlib import Path

try:
    import PyPDF2
    PDF_AVAILABLE = True
except ImportError:
    PDF_AVAILABLE = False

try:
    import pandas as pd
    PANDAS_AVAILABLE = True
except ImportError:
    PANDAS_AVAILABLE = False

from app.services.aws_service import AWSService
from app.models.api_models import (
    StatusResponse, 
    FileProcessingResult, 
    ProcessingStatus,
    ContractAnalysis
)
from app.utils.logging_config import get_logger, log_async_performance
from app.utils.pdf_processor import EnhancedPDFProcessor

logger = get_logger(__name__)


class ContractProcessor:
    """Service for processing contract documents"""
    
    def __init__(self, aws_service: AWSService):
        """
        Initialize contract processor
        
        Args:
            aws_service: AWS service instance for Bedrock calls
        """
        self.aws_service = aws_service
        self.sample_contracts_dir = Path("data/sample_contracts")
        self.output_dir = Path("data/output")
        self.state_dir = Path("data/processing_state")
        
        # Initialize enhanced PDF processor
        self.pdf_processor = EnhancedPDFProcessor()
        
        # Ensure directories exist
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.state_dir.mkdir(parents=True, exist_ok=True)
        
        # Load prompt template
        self.prompt_template = self._load_prompt_template()
        
        # Active jobs
        self.active_jobs: Dict[str, Dict[str, Any]] = {}
    
    def _load_prompt_template(self) -> str:
        """Load the prompt template from prompt.txt"""
        try:
            prompt_path = Path("prompt.txt")
            if prompt_path.exists():
                with open(prompt_path, 'r', encoding='utf-8') as f:
                    return f.read()
            else:
                logger.warning("prompt.txt not found, using default prompt")
                return "Analyze this contract and extract offshore data access restrictions."
        except Exception as e:
            logger.error(f"Failed to load prompt template: {e}")
            return "Analyze this contract and extract offshore data access restrictions."
    
    async def start_processing(
        self,
        uploaded_files: Optional[List] = None,
        use_sample_files: bool = True,
        skip_completed: bool = False
    ) -> str:
        """
        Start contract processing
        
        Args:
            uploaded_files: List of uploaded files
            use_sample_files: Whether to process sample files
            skip_completed: Whether to skip files that have been successfully processed recently
        
        Returns:
            Job ID
        """
        job_id = str(uuid.uuid4())
        
        logger.info(f"Starting contract processing job: {job_id}")
        
        # Get files to process
        files_to_process = []
        
        if use_sample_files:
            files_to_process.extend(self._get_sample_files())
        
        if uploaded_files:
            # TODO: Handle uploaded files
            logger.info(f"Processing {len(uploaded_files)} uploaded files")
        
        if not files_to_process:
            raise ValueError("No files to process")
        
        # Filter out completed files if skip_completed is True, but keep track of them
        skipped_files = []
        if skip_completed:
            original_count = len(files_to_process)
            # Use S3-based checking instead of local logs
            files_to_process, skipped_files = await self._filter_files_by_s3_status(files_to_process)
            skipped_count = len(skipped_files)
            
            if skipped_count > 0:
                logger.info(f"Skipping {skipped_count} files with existing S3 outputs")
            
            if not files_to_process:
                logger.info("All files have existing outputs in S3. No files to process.")
                # Create a completed job with no work to do, but include skipped files in output
                return await self._create_completed_job(job_id, skipped_files)
        
        # Initialize job state
        job_state = {
            "job_id": job_id,
            "status": ProcessingStatus.PENDING,
            "total_files": len(files_to_process),
            "processed_files": 0,
            "failed_files": 0,
            "files": files_to_process,
            "skipped_files": skipped_files,  # Track skipped files
            "results": [],
            "started_at": datetime.now(),
            "current_file": None,
            "error_message": None
        }
        
        self.active_jobs[job_id] = job_state
        
        # Save initial state
        await self._save_job_state(job_id, job_state)
        
        # Start processing in background
        asyncio.create_task(self._process_job(job_id))
        
        return job_id
    
    def _get_sample_files(self) -> List[str]:
        """Get list of sample contract files"""
        files = []
        
        if not self.sample_contracts_dir.exists():
            logger.warning(f"Sample contracts directory not found: {self.sample_contracts_dir}")
            return files
        
        for file_path in self.sample_contracts_dir.iterdir():
            if file_path.is_file() and file_path.suffix.lower() in ['.pdf', '.docx']:
                files.append(str(file_path))
        
        logger.info(f"Found {len(files)} sample contract files")
        return files
    
    @log_async_performance
    async def _process_job(self, job_id: str):
        """Process all files in a job"""
        job_state = self.active_jobs.get(job_id)
        if not job_state:
            logger.error(f"Job state not found for job: {job_id}")
            return
        
        try:
            job_state["status"] = ProcessingStatus.PROCESSING
            await self._save_job_state(job_id, job_state)
            
            logger.info(f"Processing {job_state['total_files']} files for job {job_id}")
            
            # Initialize results dictionary with one entry per input file
            results_by_filename = {}
            
            # Get all files (both to be processed and skipped)
            all_files = job_state["files"] + (job_state.get("skipped_files", []))
            
            # Create placeholder entries for all files
            for file_path in all_files:
                filename = Path(file_path).name
                results_by_filename[filename] = FileProcessingResult(
                    filename=filename,
                    status=ProcessingStatus.PENDING,
                    analysis=None,
                    processing_time_seconds=0.0,
                    timestamp=datetime.now(),
                    error_message=None
                )
            
            # For skipped files, load their previous results from S3
            if "skipped_files" in job_state and job_state["skipped_files"]:
                logger.info(f"Loading previous results for {len(job_state['skipped_files'])} skipped files")
                for skipped_file in job_state["skipped_files"]:
                    filename = Path(skipped_file).name
                    base_filename = Path(skipped_file).stem
                    try:
                        # Load analysis directly from S3
                        existing_analysis = await self.aws_service.get_llm_output_from_s3(filename)
                        if existing_analysis:
                            # Parse the analysis into ContractAnalysis model
                            analysis = self._parse_analysis_result(existing_analysis)
                            results_by_filename[filename] = FileProcessingResult(
                                filename=filename,
                                status=ProcessingStatus.COMPLETED,
                                analysis=analysis,
                                processing_time_seconds=0.0,  # Previous processing time not available
                                timestamp=datetime.now(),
                                error_message=None
                            )
                            logger.debug(f"✅ Loaded previous result for: {filename}")
                        else:
                            logger.warning(f"⚠️ Could not load previous result for skipped file: {filename}")
                    except Exception as e:
                        logger.warning(f"❌ Error loading previous result for {filename}: {e}")
            
            for file_path in job_state["files"]:
                if job_state["status"] != ProcessingStatus.PROCESSING:
                    break  # Job was cancelled or failed
                
                filename = Path(file_path).name
                job_state["current_file"] = filename
                await self._save_job_state(job_id, job_state)
                
                # Process individual file
                result = await self._process_file(file_path)
                
                # Update the results dictionary with the processed result
                results_by_filename[filename] = result
                
                # Also add to job_state for backward compatibility with status tracking
                job_state["results"].append(result)
                
                if result.status == ProcessingStatus.COMPLETED:
                    job_state["processed_files"] += 1
                else:
                    job_state["failed_files"] += 1
                
                await self._save_job_state(job_id, job_state)
                
                status_display = result.status.value if hasattr(result.status, 'value') else str(result.status)
                logger.info(f"Processed file {result.filename}: {status_display}")
            
            # Job completed
            job_state["status"] = ProcessingStatus.COMPLETED
            job_state["completed_at"] = datetime.now()
            job_state["current_file"] = None
            
            # Convert results dictionary to list (ensures exactly one result per file)
            all_results = list(results_by_filename.values())
            
            # Log summary
            completed_count = sum(1 for r in all_results if r.status == ProcessingStatus.COMPLETED)
            failed_count = sum(1 for r in all_results if r.status == ProcessingStatus.FAILED)
            pending_count = sum(1 for r in all_results if r.status == ProcessingStatus.PENDING)
            
            logger.info(f"Final results: {len(all_results)} total files - {completed_count} completed, {failed_count} failed, {pending_count} pending")
            
            # Generate output files with all results (exactly one per input file)
            await self._generate_output_files(job_id, all_results)
            
            logger.info(f"Job {job_id} completed successfully")
            
        except Exception as e:
            logger.error(f"Job {job_id} failed: {e}")
            job_state["status"] = ProcessingStatus.FAILED
            job_state["error_message"] = str(e)
            job_state["completed_at"] = datetime.now()
        
        finally:
            await self._save_job_state(job_id, job_state)
    
    @log_async_performance
    async def _process_file(self, file_path: str) -> FileProcessingResult:
        """
        Process a single contract file with S3-based stage management
        
        Args:
            file_path: Path to the contract file
        
        Returns:
            Processing result
        """
        filename = os.path.basename(file_path)
        start_time = datetime.now()
        
        try:
            logger.info(f"🔄 Processing file: {filename}")
            
            # Stage 1: Get text content (either from Textract processing or S3)
            contract_text = await self._get_or_extract_text(file_path)
            
            if not contract_text or len(contract_text.strip()) < 100:
                raise ValueError("Insufficient content extracted from file")
                
            # Stage 2: Get LLM analysis (either from processing or S3)
            analysis_result = await self._get_or_analyze_contract(filename, contract_text)
            
            # Convert to ContractAnalysis model
            analysis = self._parse_analysis_result(analysis_result)
            
            processing_time = (datetime.now() - start_time).total_seconds()
            
            return FileProcessingResult(
                filename=filename,
                status=ProcessingStatus.COMPLETED,
                analysis=analysis,
                processing_time_seconds=processing_time,
                timestamp=datetime.now()
            )
            
        except Exception as e:
            processing_time = (datetime.now() - start_time).total_seconds()
            logger.error(f"❌ Failed to process {filename}: {e}")
            
            return FileProcessingResult(
                filename=filename,
                status=ProcessingStatus.FAILED,
                error_message=str(e),
                processing_time_seconds=processing_time,
                timestamp=datetime.now()
            )

    async def _get_or_extract_text(self, file_path: str) -> str:
        """
        Get text content - either from existing S3 Textract output or by processing
        
        Args:
            file_path: Path to the contract file
            
        Returns:
            Extracted text content
        """
        filename = os.path.basename(file_path)
        
        # Check if Textract output already exists in S3
        if await self.aws_service.check_textract_output_exists(filename):
            logger.info(f"📥 Retrieving existing Textract output from S3 for: {filename}")
            text = await self.aws_service.get_textract_output_from_s3(filename)
            if text:
                return text
            else:
                logger.warning(f"⚠️ Failed to retrieve existing Textract output, will reprocess: {filename}")
        
        # Need to process with Textract
        logger.info(f"🚀 Processing {filename} with Textract (no existing output found)")
        return await self._extract_text_from_file(file_path)

    async def _get_or_analyze_contract(self, filename: str, contract_text: str) -> Dict[str, Any]:
        """
        Get LLM analysis - either from existing S3 output or by processing
        
        Args:
            filename: Name of the contract file
            contract_text: Extracted contract text
            
        Returns:
            LLM analysis result
        """
        logger.info(f"DEBUG: _get_or_analyze_contract called for: {filename}")
        # Check if LLM output already exists in S3
        logger.info(f"DEBUG: Checking LLM output existence for: {filename}")
        llm_exists = await self.aws_service.check_llm_output_exists(filename)
        logger.info(f"DEBUG: LLM exists check result: {llm_exists}")
        
        if llm_exists:
            logger.info(f"DEBUG: Retrieving existing LLM analysis from S3 for: {filename}")
            # Try to load existing LLM output
            existing_result = await self.aws_service.get_llm_output_from_s3(filename)
            logger.info(f"DEBUG: Retrieved result type: {type(existing_result)}, is None: {existing_result is None}")
            if existing_result:
                logger.info(f"DEBUG: Successfully retrieved existing LLM analysis for: {filename}")
                return existing_result  # Return here to avoid calling LLM again
            else:
                logger.warning(f"DEBUG: Failed to retrieve existing LLM output, will reprocess: {filename}")
        else:
            logger.info(f"DEBUG: Processing {filename} with LLM (no existing output found)")
        
        # Process with LLM (only if existing output not found or failed to load)
        logger.info(f"🚀 Calling AWS Bedrock for LLM analysis: {filename}")
        analysis_result = await self.aws_service.analyze_contract(
            contract_text, 
            self.prompt_template
        )
        
        # Save LLM output to S3
        base_filename = Path(filename).stem
        try:
            s3_key = await self.aws_service.save_llm_output_to_s3(base_filename, analysis_result)
            logger.info(f"💾 LLM output saved to S3: {s3_key}")
        except Exception as e:
            logger.error(f"❌ Failed to save LLM output to S3: {e}")
        
        return analysis_result
    
    async def _extract_text_from_file(self, file_path: str) -> str:
        """Extract text content from PDF or DOCX file using enhanced processing"""
        file_ext = Path(file_path).suffix.lower()
        
        if file_ext == '.pdf':
            return await self.pdf_processor.extract_text_from_pdf(file_path)
        elif file_ext == '.docx':
            return await self._extract_docx_text(file_path)
        else:
            raise ValueError(f"Unsupported file format: {file_ext}")
    
    async def _extract_pdf_text(self, file_path: str) -> str:
        """Extract text from PDF file - DEPRECATED: Use enhanced processor instead"""
        logger.warning("Using deprecated PDF extraction method. Use enhanced processor instead.")
        return await self.pdf_processor.extract_text_from_pdf(file_path)
    
    async def _extract_docx_text(self, file_path: str) -> str:
        """Extract text from DOCX file"""
        # TODO: Implement DOCX text extraction
        raise NotImplementedError("DOCX processing not yet implemented")
    
    def _parse_analysis_result(self, analysis_result: Dict[str, Any]) -> Optional[ContractAnalysis]:
        """Parse analysis result into ContractAnalysis model"""
        try:
            if "error" in analysis_result:
                logger.warning(f"Analysis error: {analysis_result['error']}")
                return None
            
            # Create ContractAnalysis from the result
            # The result should already match our expected schema
            return ContractAnalysis(**analysis_result)
            
        except Exception as e:
            logger.error(f"Failed to parse analysis result: {e}")
            return None
    
    async def _generate_output_files(self, job_id: str, results: List[FileProcessingResult]):
        """Generate CSV and Excel output files"""
        try:
            if not PANDAS_AVAILABLE:
                logger.warning("Pandas not available, skipping output file generation")
                return
            
            # Prepare data for output
            output_data = []
            
            for result in results:
                if result.analysis:
                    # Flatten the analysis data
                    row = {
                        "filename": result.filename,
                        "processing_status": result.status.value if hasattr(result.status, 'value') else str(result.status),
                        "processing_time_seconds": result.processing_time_seconds,
                        "timestamp": result.timestamp.isoformat(),
                        "counterparty": result.analysis.counterparty,
                        "contract_title": result.analysis.contractTitle,
                        "contract_date": result.analysis.contractDate,
                    }
                    
                    # Add offshore data provision details
                    if result.analysis.offshoreDataProvision:
                        odp = result.analysis.offshoreDataProvision
                        row.update({
                            "has_restriction": odp.hasRestriction,
                            "restriction_section": odp.section,
                            "restriction_text": odp.restrictionText,
                            "restriction_type": odp.restrictionType,
                            "notification_period": odp.notificationPeriod,
                            "geographic_scope": odp.geographicScope,
                            "authorized_locations": ", ".join(odp.authorizedLocations or []),
                            "exceptions": odp.exceptions
                        })
                    
                    # Add other fields as needed
                    output_data.append(row)
                else:
                    # Failed processing
                    output_data.append({
                        "filename": result.filename,
                        "processing_status": result.status.value if hasattr(result.status, 'value') else str(result.status),
                        "error_message": result.error_message,
                        "processing_time_seconds": result.processing_time_seconds,
                        "timestamp": result.timestamp.isoformat()
                    })
            
            if output_data:
                df = pd.DataFrame(output_data)
                
                # Generate timestamped filename
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                
                # Save as CSV
                csv_path = self.output_dir / f"contract_analysis_{timestamp}.csv"
                df.to_csv(csv_path, index=False)
                logger.info(f"Results saved to CSV: {csv_path}")
                
                # Save as Excel
                excel_path = self.output_dir / f"contract_analysis_{timestamp}.xlsx"
                with pd.ExcelWriter(excel_path, engine='openpyxl') as writer:
                    df.to_excel(writer, sheet_name='Analysis Results', index=False)
                    
                    # Add metadata sheet
                    metadata = pd.DataFrame([{
                        "job_id": job_id,
                        "total_files": len(results),
                        "successful": len([r for r in results if r.status == ProcessingStatus.COMPLETED]),
                        "failed": len([r for r in results if r.status == ProcessingStatus.FAILED]),
                        "generated_at": datetime.now().isoformat()
                    }])
                    metadata.to_excel(writer, sheet_name='Metadata', index=False)
                
                logger.info(f"Results saved to Excel: {excel_path}")
                
        except Exception as e:
            logger.error(f"Failed to generate output files: {e}")
    
    async def _save_job_state(self, job_id: str, job_state: Dict[str, Any]):
        """Save job state to file"""
        try:
            state_file = self.state_dir / f"job_{job_id}.json"
            
            # Convert datetime objects to strings for JSON serialization
            serializable_state = self._make_json_serializable(job_state.copy())
            
            with open(state_file, 'w') as f:
                json.dump(serializable_state, f, indent=2, default=str)
                
        except Exception as e:
            logger.error(f"Failed to save job state: {e}")
    
    def _make_json_serializable(self, obj):
        """Make object JSON serializable"""
        if isinstance(obj, datetime):
            return obj.isoformat()
        elif hasattr(obj, 'value'):  # Handle enum objects
            return obj.value
        elif isinstance(obj, dict):
            return {k: self._make_json_serializable(v) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [self._make_json_serializable(item) for item in obj]
        elif hasattr(obj, '__dict__'):
            return self._make_json_serializable(obj.__dict__)
        else:
            return obj
    
    async def get_job_status(self, job_id: str) -> Optional[StatusResponse]:
        """Get status of a processing job"""
        job_state = self.active_jobs.get(job_id)
        
        if not job_state:
            # Try to load from file
            job_state = await self._load_job_state(job_id)
        
        if not job_state:
            return None
        
        return StatusResponse(
            job_id=job_id,
            status=job_state["status"],
            total_files=job_state["total_files"],
            processed_files=job_state["processed_files"],
            failed_files=job_state["failed_files"],
            current_file=job_state.get("current_file"),
            results=job_state.get("results", []),
            started_at=job_state.get("started_at"),
            completed_at=job_state.get("completed_at"),
            error_message=job_state.get("error_message")
        )
    
    async def _load_job_state(self, job_id: str) -> Optional[Dict[str, Any]]:
        """Load job state from file"""
        try:
            state_file = self.state_dir / f"job_{job_id}.json"
            
            if state_file.exists():
                with open(state_file, 'r') as f:
                    return json.load(f)
                    
        except Exception as e:
            logger.error(f"Failed to load job state: {e}")
        
        return None
    
    async def get_results(self, job_id: str, format: str = "json"):
        """Get processing results for a job"""
        job_state = self.active_jobs.get(job_id)
        
        if not job_state:
            job_state = await self._load_job_state(job_id)
        
        if not job_state:
            return None
        
        if format.lower() == "json":
            return {"results": job_state.get("results", [])}
        
        # TODO: Return CSV/Excel file download
        return {"message": "File download not yet implemented"}
    
    async def resume_processing(self) -> str:
        """Resume interrupted processing"""
        # TODO: Implement resume functionality
        # Look for incomplete jobs and resume them
        raise NotImplementedError("Resume processing not yet implemented")
    
    async def _filter_files_by_s3_status(self, files_to_process: List[str]) -> tuple[List[str], List[str]]:
        """
        Filter files based on S3 output existence (Textract and LLM)
        
        Args:
            files_to_process: List of file paths to check
            
        Returns:
            Tuple of (files_needing_processing, skipped_files)
        """
        files_needing_processing = []
        skipped_files = []
        
        for file_path in files_to_process:
            filename = os.path.basename(file_path)
            base_filename = Path(filename).stem
            
            # Check if both Textract and LLM outputs exist in S3
            textract_exists = await self.aws_service.check_textract_output_exists(filename)
            llm_exists = await self.aws_service.check_llm_output_exists(filename)
            
            if textract_exists and llm_exists:
                # Both outputs exist, skip this file
                skipped_files.append(file_path)
                logger.debug(f"✅ Skipping {filename} - both Textract and LLM outputs exist in S3")
            else:
                # At least one output missing, need to process
                files_needing_processing.append(file_path)
                if not textract_exists:
                    logger.debug(f"📄 {filename} needs Textract processing")
                if not llm_exists:
                    logger.debug(f"🤖 {filename} needs LLM processing")
        
        logger.info(f"S3 status check: {len(files_needing_processing)} files need processing, {len(skipped_files)} completely processed")
        return files_needing_processing, skipped_files
    
    async def _get_recently_completed_files(self) -> set:
        """
        Get set of filenames that have been successfully processed recently
        
        Returns:
            Set of filenames that were successfully processed in the last 24 hours
        """
        completed_files = set()
        cutoff_time = datetime.now() - timedelta(hours=24)
        
        # Check all job state files for recent successful completions
        if not self.state_dir.exists():
            return completed_files
            
        for state_file in self.state_dir.glob("job_*.json"):
            try:
                with open(state_file, 'r') as f:
                    job_data = json.load(f)
                
                # Check if job was completed recently
                completed_at = job_data.get("completed_at")
                if not completed_at:
                    continue
                
                # Parse completion time
                if isinstance(completed_at, str):
                    completed_time = datetime.fromisoformat(completed_at.replace('Z', '+00:00'))
                else:
                    continue
                
                # Skip if too old
                if completed_time < cutoff_time:
                    continue
                
                # Add successfully processed files
                results = job_data.get("results", [])
                for result in results:
                    if isinstance(result, dict):
                        status = result.get("status")
                        filename = result.get("filename")
                        
                        # Check if status indicates success (handle multiple formats)
                        is_completed = False
                        if status:
                            if isinstance(status, str):
                                is_completed = status == "completed"
                            elif isinstance(status, dict) and status.get("_value_") == "completed":
                                is_completed = True
                            elif hasattr(status, 'value') and status.value == "completed":
                                is_completed = True
                            elif str(status) == "ProcessingStatus.COMPLETED":
                                is_completed = True
                        
                        if filename and is_completed:
                            completed_files.add(filename)
                            logger.debug(f"Found completed file: {filename}")
                    
            except (json.JSONDecodeError, ValueError, KeyError) as e:
                logger.warning(f"Error reading job state file {state_file}: {e}")
                continue
        
        logger.info(f"Found {len(completed_files)} recently completed files")
        return completed_files
    
    async def _create_completed_job(self, job_id: str, skipped_files: List[str] = None) -> str:
        """
        Create a job that is already completed (when all files are skipped)
        
        Args:
            job_id: Job ID to use
            skipped_files: List of files that were skipped
            
        Returns:
            Job ID
        """
        if skipped_files is None:
            skipped_files = []
            
        # Load previous results for skipped files to include in output
        skipped_results = await self._load_previous_results_for_files(skipped_files)
        
        job_state = {
            "job_id": job_id,
            "status": ProcessingStatus.COMPLETED,
            "total_files": 0,
            "processed_files": 0,
            "failed_files": 0,
            "files": [],
            "skipped_files": skipped_files,
            "results": skipped_results,  # Include previous results for skipped files
            "started_at": datetime.now(),
            "completed_at": datetime.now(),
            "current_file": None,
            "error_message": None
        }
        
        self.active_jobs[job_id] = job_state
        await self._save_job_state(job_id, job_state)
        
        # Generate output files with skipped file results
        if skipped_results:
            await self._generate_output_files(job_id, skipped_results)
        
        logger.info(f"Created completed job {job_id} - all files were already processed, included {len(skipped_results)} previous results")
        return job_id
    
    async def _load_previous_results_for_files(self, file_paths: List[str]) -> List['FileProcessingResult']:
        """
        Load previous processing results for the given files
        
        Args:
            file_paths: List of file paths to load results for
            
        Returns:
            List of FileProcessingResult objects
        """
        results = []
        
        if not file_paths:
            return results
            
        # Get recently completed files with their results
        cutoff_time = datetime.now() - timedelta(hours=24)
        
        # Check all job state files for results
        if not self.state_dir.exists():
            return results
            
        for state_file in self.state_dir.glob("job_*.json"):
            try:
                with open(state_file, 'r') as f:
                    job_data = json.load(f)
                
                # Check if this job has results for our files
                if 'results' in job_data and 'completed_at' in job_data:
                    completed_at = datetime.fromisoformat(job_data['completed_at'])
                    
                    if completed_at >= cutoff_time:
                        # Check each result to see if it matches our files
                        for result_data in job_data['results']:
                            result_filename = result_data.get('filename', '')
                            
                            # Check if this result is for one of our skipped files
                            for file_path in file_paths:
                                if os.path.basename(file_path) == result_filename:
                                    # Convert back to FileProcessingResult object
                                    result = FileProcessingResult(
                                        filename=result_data.get('filename', ''),
                                        status=ProcessingStatus(result_data.get('status', 'failed')),
                                        processing_time_seconds=result_data.get('processing_time_seconds', 0),
                                        timestamp=datetime.fromisoformat(result_data.get('timestamp', datetime.now().isoformat())),
                                        error_message=result_data.get('error_message'),
                                        analysis=result_data.get('analysis')  # This will be handled by Pydantic
                                    )
                                    results.append(result)
                                    break
                    
            except Exception as e:
                logger.warning(f"Failed to load job state from {state_file}: {e}")
                continue
        
        # Deduplicate results by filename, keeping the most recent result for each file
        if results:
            # Group results by filename and keep the most recent
            filename_to_result = {}
            for result in results:
                filename = result.filename
                if filename not in filename_to_result or result.timestamp > filename_to_result[filename].timestamp:
                    filename_to_result[filename] = result
            
            # Convert back to list
            deduplicated_results = list(filename_to_result.values())
            logger.info(f"Deduplicated {len(results)} results to {len(deduplicated_results)} unique files")
            results = deduplicated_results
        
        logger.info(f"Loaded {len(results)} previous results for skipped files")
        return results
