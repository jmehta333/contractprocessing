# Contract Processing API

A FastAPI application for processing legal contracts to extract offshore data access restrictions using AWS Bedrock Claude Sonnet model and AWS Textract for document text extraction.

## 🏗️ Architecture

The system uses a two-stage S3-based processing pipeline:

1. **Text Extraction Stage**: AWS Textract extracts text from PDF contracts
   - Outputs stored in `s3://contract-processing/textract/output/`
   - Handles both native PDFs and scanned documents
   
2. **AI Analysis Stage**: AWS Bedrock Claude Sonnet analyzes extracted text
   - Outputs stored in `s3://contract-processing/llm/`
   - Extracts offshore data access restrictions

3. **Result Generation**: Creates Excel/CSV reports with findings
   - Local outputs in `data/output/`
   - Includes both processed and skipped files

## ✨ Features

- 🔍 **Smart Contract Analysis**: Extracts offshore data restrictions from legal contracts
- 🤖 **AWS Textract Integration**: Advanced OCR for scanned and complex PDFs
- 🧠 **AI-Powered Analysis**: Uses Anthropic Claude Sonnet via AWS Bedrock
- 📊 **Multiple Output Formats**: Generates comprehensive CSV and Excel reports
- ☁️ **S3-Based Processing**: Reliable cloud storage for all processing stages
- 🔄 **Intelligent Resuming**: Skips already processed files by checking S3
- 📈 **Detailed Progress Tracking**: Real-time status monitoring with job polling
- 📝 **Comprehensive Logging**: CloudWatch integration with detailed progress reports
- 🚀 **Production Ready**: Deployable to AWS AppRunner with proper error handling

## 🚀 Quick Start

### Prerequisites

- Python 3.11+
- AWS Account with Bedrock and Textract access
- S3 bucket: `contract-processing`
- AWS CLI configured or environment variables set

### Local Development Setup

1. **Clone and navigate to the project**:
   ```bash
   cd contract-processing
   ```

2. **Create and activate virtual environment**:
   ```bash
   python -m venv .venv
   .venv\Scripts\activate  # Windows
   # or
   source .venv/bin/activate  # Linux/Mac
   ```

3. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

4. **Configure environment variables**:
   Copy `.env.example` to `.env` and update with your AWS credentials:
   ```bash
   AWS_PROFILE=your-aws-profile
   AWS_REGION=us-east-1
   S3_BUCKET=contract-processing
   BEDROCK_MODEL_ID=anthropic.claude-3-5-sonnet-20240620-v1:0
   CLOUDWATCH_LOG_GROUP=contract-processing-api
   ```

5. **Run the application**:
   ```bash
   python -m uvicorn app.main:app --reload --port 8000
   ```

6. **Access the API**:
   - Swagger UI: http://localhost:8000/docs
   - ReDoc: http://localhost:8000/redoc
   - Health Check: http://localhost:8000/health

## API Endpoints

### Core Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/health` | Health check and service status |
| POST | `/process-contracts` | Start contract processing |
| GET | `/status/{job_id}` | Get processing status |
| GET | `/results/{job_id}` | Download results |
| POST | `/resume-processing` | Resume interrupted processing |
| GET | `/files` | List available contract files |

### Usage Examples

#### Start Processing Sample Contracts
```bash
curl -X POST "http://localhost:8000/process-contracts" \
     -H "Content-Type: application/json" \
     -d '{"use_sample_files": true}'
```

#### Check Processing Status
```bash
curl "http://localhost:8000/status/{job_id}"
```

#### Get Results
```bash
curl "http://localhost:8000/results/{job_id}?format=json"
```

## 📁 Project Structure

```
contract-processing/
├── app/
│   ├── __init__.py
│   ├── main.py                 # FastAPI application
│   ├── models/
│   │   ├── __init__.py
│   │   └── api_models.py       # Pydantic models
│   ├── services/
│   │   ├── __init__.py
│   │   ├── aws_service.py      # AWS Bedrock & S3 integration
│   │   └── contract_processor.py # S3-based processing logic
│   └── utils/
│       ├── __init__.py
│       ├── logging_config.py   # Logging configuration
│       └── pdf_processor.py    # AWS Textract integration
├── data/
│   ├── sample_contracts/       # Sample PDF contracts
│   ├── output/                 # Generated Excel/CSV reports
│   └── processing_state/       # Job state files (local tracking)
├── tests/                      # Unit tests
├── .env                        # Environment variables
├── .gitignore                  # Git ignore patterns
├── Dockerfile                  # Docker configuration
├── requirements.txt            # Python dependencies
├── prompt.txt                  # LLM prompt template
├── CHECKLIST.md               # Implementation checklist
└── README.md                   # This file
```

## ☁️ AWS S3 Structure

```
s3://contract-processing/
├── textract/
│   ├── temp/                   # Temporary files (auto-deleted)
│   └── output/                 # Textract extraction results
│       ├── {filename}_textract.json    # Full Textract response
│       └── {filename}_textract.txt     # Extracted text only
└── llm/                        # LLM analysis results
    ├── {filename}_analysis.json       # Full LLM response
    └── {filename}_analysis.txt        # Analysis summary
```

## ⚙️ Configuration

### Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `AWS_PROFILE` | AWS profile name | - |
| `S3_BUCKET` | S3 bucket for processing files | `contract-processing` |
| `AWS_REGION` | AWS region | `us-east-1` |
| `BEDROCK_MODEL_ID` | Claude model ID | `anthropic.claude-3-5-sonnet-20240620-v1:0` |
| `CLOUDWATCH_LOG_GROUP` | CloudWatch log group | `contract-processing-api` |
| `MAX_TOKENS` | Maximum tokens for LLM | `4096` |
| `TEMPERATURE` | LLM temperature | `0.1` |
| `DEBUG` | Enable debug mode | `True` |
| `API_PORT` | API server port | `8000` |
| `MAX_FILE_SIZE_MB` | Max upload file size | `50` |

### AWS Credentials

The application supports multiple AWS credential methods:

1. **AWS Profile** (Recommended for local development):
   ```bash
   AWS_PROFILE=your-profile-name
   ```

2. **Environment Variables**:
   ```bash
   AWS_ACCESS_KEY_ID=your-access-key
   AWS_SECRET_ACCESS_KEY=your-secret-key
   ```

3. **IAM Roles** (For AWS AppRunner deployment):
   Automatically detected in AWS environment

## Docker Deployment

### Build Docker Image
```bash
docker build -t contract-processing-api .
```

### Run Container
```bash
docker run -p 8000:8000 \
  -e AWS_PROFILE=your-profile \
  -e AWS_REGION=us-east-1 \
  -v ~/.aws:/root/.aws:ro \
  contract-processing-api
```

## AWS AppRunner Deployment

### Prerequisites
- AWS AppRunner service configured
- IAM role with Bedrock and CloudWatch permissions
- ECR repository for container images

### Deployment Steps

1. **Push image to ECR**:
   ```bash
   aws ecr get-login-password --region us-east-1 | docker login --username AWS --password-stdin 123456789012.dkr.ecr.us-east-1.amazonaws.com
   docker tag contract-processing-api:latest 123456789012.dkr.ecr.us-east-1.amazonaws.com/contract-processing-api:latest
   docker push 123456789012.dkr.ecr.us-east-1.amazonaws.com/contract-processing-api:latest
   ```

2. **Create AppRunner service**:
   ```bash
   aws apprunner create-service \
     --service-name contract-processing-api \
     --source-configuration file://apprunner-config.json
   ```

### Required IAM Permissions

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "bedrock:InvokeModel",
        "bedrock:ListFoundationModels"
      ],
      "Resource": "*"
    },
    {
      "Effect": "Allow",
      "Action": [
        "logs:CreateLogGroup",
        "logs:CreateLogStream",
        "logs:PutLogEvents"
      ],
      "Resource": "arn:aws:logs:*:*:log-group:contract-processing-*"
    }
  ]
}
```

## Output Format

The API generates analysis results in both CSV and Excel formats with the following structure:

### CSV/Excel Columns

| Column | Description |
|--------|-------------|
| `filename` | Contract file name |
| `processing_status` | Success/failure status |
| `counterparty` | Other party in contract |
| `contract_title` | Full contract title |
| `contract_date` | Contract execution date |
| `has_restriction` | Whether offshore restriction exists |
| `restriction_text` | Exact restriction language |
| `restriction_type` | Type of restriction |
| `geographic_scope` | Geographic limitations |
| `notification_period` | Required notification period |

## Development

### Running Tests
```bash
pytest tests/
```

### Code Formatting
```bash
black app/
isort app/
```

### Linting
```bash
flake8 app/
mypy app/
```

## Troubleshooting

### Common Issues

1. **AWS Credentials Not Found**
   - Verify AWS profile or environment variables
   - Check IAM permissions for Bedrock access

2. **PDF Processing Errors**
   - Ensure PyPDF2 is installed
   - Check file permissions and corruption

3. **CloudWatch Logging Issues**
   - Verify log group exists
   - Check IAM permissions for CloudWatch

4. **High Memory Usage**
   - Large PDF files may consume significant memory
   - Consider processing files in smaller batches

### Debug Mode

Enable debug logging:
```bash
DEBUG=True
LOG_LEVEL=DEBUG
```

### Health Check

Monitor service health:
```bash
curl http://localhost:8000/health
```

## Performance Considerations

- **Batch Processing**: Process files in configurable batch sizes
- **Memory Management**: Large PDFs are processed page by page
- **Rate Limiting**: Bedrock API calls respect rate limits
- **Caching**: Results are cached to avoid duplicate processing

## Security

- **Input Validation**: All inputs are validated using Pydantic
- **File Size Limits**: Configurable maximum file sizes
- **AWS IAM**: Least privilege access principles
- **Environment Variables**: Sensitive data stored securely

## Monitoring

- **CloudWatch Logs**: Structured JSON logging
- **Performance Metrics**: Processing time tracking
- **Error Tracking**: Comprehensive error logging
- **Health Checks**: Built-in health monitoring

## Future Enhancements

- [ ] Box API integration for cloud file access
- [ ] DOCX file processing support
- [ ] Batch upload functionality
- [ ] Real-time WebSocket status updates
- [ ] Advanced filtering and search
- [ ] Multiple language support

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make changes with tests
4. Submit a pull request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Support

For support and questions:
- Create an issue in the repository
- Check the troubleshooting section
- Review AWS Bedrock documentation
