# Contract Processing System - Architecture & Process Flow

## Table of Contents
1. [System Overview](#system-overview)
2. [High-Level Architecture](#high-level-architecture)
3. [Process Flow](#process-flow)
4. [Core Components](#core-components)
5. [AWS Services Integration](#aws-services-integration)
6. [Data Flow](#data-flow)
7. [File Processing Logic](#file-processing-logic)
8. [Cost Optimization](#cost-optimization)
9. [Error Handling](#error-handling)
10. [Output Generation](#output-generation)

---

## System Overview

The Contract Processing System is an automated solution that extracts text from PDF contracts and analyzes them for data security and offshore processing provisions using AI. The system is designed to be cost-effective, reliable, and scalable.

### Key Features
- **Text Extraction**: Uses AWS Textract for reliable PDF text extraction (including scanned documents)
- **AI Analysis**: Uses AWS Bedrock (Claude Sonnet 3.5) for intelligent contract analysis
- **Cost Optimization**: Intelligent caching to avoid duplicate processing
- **S3-Based Storage**: All outputs stored in AWS S3 for persistence and reliability
- **Comprehensive Reporting**: Generates Excel and CSV reports with analysis results

---

## High-Level Architecture

```mermaid
flowchart TB
    A[PDF Contracts] --> B[FastAPI Server]
    B --> C[Contract Processor]
    C --> D[AWS Service]
    
    D --> E[AWS Textract]
    D --> F[AWS Bedrock] 
    D --> G[AWS S3]
    
    E --> H[Text Results]
    F --> I[AI Analysis]
    G --> J[Cached Data]
    
    H --> K[Excel Reports]
    I --> K
    J --> K
```

---

## Process Flow

The system follows a two-stage processing pipeline with intelligent caching:

### Stage 1: Text Extraction
```mermaid
flowchart TD
    A[Input PDF] --> B{Cached?}
    B -->|Yes| C[Load Cache]
    B -->|No| D[Run Textract]
    D --> E[Save Cache]
    E --> F[Return Text]
    C --> F
```

### Stage 2: AI Analysis  
```mermaid
flowchart TD
    A[Text Input] --> B{Analyzed?}
    B -->|Yes| C[Load Result]
    B -->|No| D[Run Bedrock]
    D --> E[Save Result]
    E --> F[Return Analysis]
    C --> F
```

### Complete Processing Workflow
```mermaid
sequenceDiagram
    participant User
    participant API
    participant AWS
    
    User->>API: Process contracts
    API->>AWS: Check cache
    AWS-->>API: Return status
    API->>AWS: Process files
    AWS-->>API: Results
    API-->>User: Excel report
```

---

## Core Components

### 1. FastAPI Server (`app/main.py`)
- **Purpose**: HTTP API endpoint for contract processing
- **Key Endpoints**:
  - `POST /contracts/process`: Start contract processing
  - `GET /contracts/status/{job_id}`: Check processing status
  - `GET /contracts/results/{job_id}`: Download results

### 2. Contract Processor (`app/services/contract_processor.py`)
- **Purpose**: Orchestrates the entire processing workflow
- **Key Responsibilities**:
  - Manages job state and progress tracking
  - Coordinates file filtering and processing
  - Handles result aggregation and deduplication
  - Generates output files

### 3. AWS Service (`app/services/aws_service.py`)
- **Purpose**: Manages all AWS service interactions
- **Key Responsibilities**:
  - AWS Textract integration for text extraction
  - AWS Bedrock integration for AI analysis
  - S3 storage operations for caching
  - Credential and profile management

### 4. PDF Processor (`app/utils/pdf_processor.py`)
- **Purpose**: Handles PDF text extraction using AWS Textract
- **Key Features**:
  - Supports both sync and async Textract processing
  - Handles multi-page documents
  - Progress reporting for long-running extractions

---

## AWS Services Integration

### AWS Textract
```yaml
Purpose: PDF text extraction
Input: PDF files (local or S3)
Output: Structured text content
Storage: S3 bucket under textract/output/
Naming: {filename}-{timestamp}.txt
```

### AWS Bedrock (Claude Sonnet 3.5)
```yaml
Purpose: Contract analysis and data extraction
Input: Extracted text + analysis prompt
Output: Structured JSON with contract details
Storage: S3 bucket under llm/output/
Naming: {base_filename}-{timestamp}.json
```

### S3 Storage Structure
```
contract-processing/
├── textract/
│   └── output/
│       ├── Contract1-1234567890.txt
│       └── Contract2-1234567891.txt
└── llm/
    └── output/
        ├── Contract1-1234567892.json
        └── Contract2-1234567893.json
```

---

## Data Flow

### Input Data
- **Source**: PDF contract files in `data/sample_contracts/`
- **Format**: PDF documents (scanned or text-based)
- **Count**: Currently ~41 contract files

### Processing Pipeline
1. **File Discovery**: Scan sample contracts directory
2. **S3 Status Check**: Determine which files need processing
3. **Text Extraction**: Extract text using AWS Textract (if not cached)
4. **AI Analysis**: Analyze content using AWS Bedrock (if not cached)
5. **Result Compilation**: Aggregate results ensuring one entry per file
6. **Output Generation**: Create Excel and CSV reports

### Output Data
- **Excel File**: `data/output/contract_analysis_{timestamp}.xlsx`
- **CSV File**: `data/output/contract_analysis_{timestamp}.csv`
- **Columns**:
  - `filename`: Original contract filename
  - `counterparty`: Identified counterparty organization
  - `contractTitle`: Contract title/description
  - `contractDate`: Contract effective date
  - `offshoreDataProvision`: Whether offshore data processing is mentioned
  - `dataSubject`: Type of data covered
  - `restrictionDirection`: Direction of data restrictions
  - `complianceRequirements`: Specific compliance requirements
  - `analysisNotes`: Additional analysis notes
  - `processing_time_seconds`: Time taken to process
  - `timestamp`: When processing completed

---

## File Processing Logic

### Intelligent File Filtering
The system uses S3-based caching to avoid unnecessary processing:

```python
def determine_processing_needed(filename):
    textract_exists = check_s3_exists(f"textract/output/{filename}")
    llm_exists = check_s3_exists(f"llm/output/{base_filename}")
    
    if textract_exists and llm_exists:
        return "SKIP"  # Complete, load from S3
    elif textract_exists and not llm_exists:
        return "LLM_ONLY"  # Only need AI analysis
    elif not textract_exists and llm_exists:
        return "TEXTRACT_ONLY"  # Only need text extraction
    else:
        return "FULL_PROCESSING"  # Need both stages
```

### Result Deduplication Strategy
To ensure exactly one result per input file:

```python
# Initialize results dictionary with all input files
results_by_filename = {}
for file_path in all_input_files:
    filename = Path(file_path).name
    results_by_filename[filename] = create_placeholder_result(filename)

# For skipped files, load from S3
for skipped_file in skipped_files:
    load_result_from_s3(skipped_file, results_by_filename)

# For processed files, update as they complete
for processed_file in files_to_process:
    result = process_file(processed_file)
    results_by_filename[result.filename] = result

# Generate final output (guaranteed 1 result per input file)
final_results = list(results_by_filename.values())
```

---

## Cost Optimization

### AWS Cost Management
The system implements several strategies to minimize AWS costs:

1. **Intelligent Caching**:
   - All Textract outputs cached in S3
   - All LLM analyses cached in S3
   - Prevents duplicate processing of same files

2. **Efficient S3 Operations**:
   - Batch file existence checks
   - Prefix-based object listing
   - Minimal data transfer

3. **Smart Processing**:
   - Skip files with existing complete results
   - Process only missing components (text OR analysis)
   - Avoid unnecessary API calls

### Cost Monitoring
```yaml
Textract Costs: ~$1.50 per 1000 pages
Bedrock Costs: ~$3.00 per 1M input tokens, ~$15.00 per 1M output tokens
S3 Storage: ~$0.023 per GB per month
S3 Requests: ~$0.0004 per 1000 requests
```

---

## Error Handling

### Processing Errors
The system handles various error scenarios:

1. **PDF Processing Errors**:
   - Corrupt or unreadable PDFs
   - Textract service limits
   - Network connectivity issues

2. **LLM Analysis Errors**:
   - Invalid JSON responses
   - Model timeout errors
   - Content policy violations

3. **S3 Storage Errors**:
   - Permission denied
   - Storage quota exceeded
   - Network failures

### Error Recovery
```python
try:
    result = process_file(file_path)
    status = ProcessingStatus.COMPLETED
except Exception as e:
    result = create_error_result(file_path, str(e))
    status = ProcessingStatus.FAILED
    logger.error(f"Failed to process {file_path}: {e}")
```

---

## Output Generation

### Excel Report Structure
The Excel file contains:
- **One row per input contract file** (exactly 41 rows for 41 files)
- **Structured analysis data** extracted by AI
- **Processing metadata** (timestamps, processing time)
- **Status indicators** (completed, failed, pending)

### Data Validation
- **Enum Validation**: Ensures consistent values for categorical fields
- **Date Parsing**: Converts extracted dates to standardized format
- **Error Handling**: Captures validation errors in analysis notes

### Report Generation Process
```mermaid
graph LR
    A[Results] --> B[DataFrame]
    B --> C[Validation]
    C --> D[Excel File]
    C --> E[CSV File]
```

---

## Configuration

### Environment Variables
```yaml
AWS_PROFILE: GENAI-POC_AWSAdministratorAccess
AWS_REGION: us-east-1
AWS_S3_BUCKET: contract-processing
BEDROCK_MODEL_ID: anthropic.claude-3-5-sonnet-20240620-v1:0
LOG_LEVEL: INFO
```

### File Paths
```yaml
Input Directory: data/sample_contracts/
Output Directory: data/output/
State Directory: data/state/
Log Directory: logs/
```

---

## Troubleshooting

### Common Issues

1. **Duplicate Results in Excel**:
   - **Cause**: Multiple job runs loading from different state files
   - **Solution**: Use the new results dictionary approach (one entry per file)

2. **LLM Analysis Not Found**:
   - **Cause**: Filename truncation due to double Path().stem operation
   - **Solution**: Fixed by using base_filename directly in save operation

3. **High AWS Costs**:
   - **Cause**: Reprocessing files that already have results
   - **Solution**: S3-based caching prevents duplicate processing

4. **Processing Timeouts**:
   - **Cause**: Large documents or API rate limits
   - **Solution**: Async processing with proper timeout handling

### Debugging Tools
- **Logs**: Comprehensive logging in `logs/contract_processing.log`
- **Job State**: Real-time job status in `data/state/job_{id}.json`
- **S3 Browser**: Direct inspection of cached results in S3 console

---

## Future Enhancements

### Potential Improvements
1. **Web Dashboard**: Real-time processing monitoring
2. **Batch Upload**: Support for user-uploaded contract files
3. **Advanced Analytics**: Trend analysis across contract portfolios
4. **Multi-tenant Support**: Support for multiple organizations
5. **API Rate Limiting**: Better handling of AWS service limits

### Scalability Considerations
1. **Horizontal Scaling**: Support for multiple worker processes
2. **Database Integration**: Replace file-based state with database
3. **Message Queues**: Asynchronous job processing with SQS
4. **Containerization**: Docker deployment for cloud environments

---

*This documentation was last updated on August 11, 2025. For questions or updates, please contact the development team.*
