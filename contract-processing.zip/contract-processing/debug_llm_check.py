#!/usr/bin/env python3
"""
Debug script to check LLM output existence
"""
import asyncio
import sys
from pathlib import Path

# Add the app directory to the path
sys.path.append(str(Path(__file__).parent / "app"))

from app.services.aws_service import AWSService

async def debug_llm_check():
    """Debug LLM output checking"""
    aws_service = AWSService()
    
    # Test files that we know have LLM outputs
    test_files = [
        "206641_EnTitle Insurance Company_Master WFBank.pdf",
        "BANA Privacy and Security Agreement.pdf",
        "Bank of America - Radian Guaranty GSA dated 080922.pdf"
    ]
    
    for filename in test_files:
        print(f"\n🔍 Testing: {filename}")
        
        # Check if LLM output exists
        exists = await aws_service.check_llm_output_exists(filename)
        print(f"   LLM exists: {exists}")
        
        if exists:
            # Try to retrieve it
            result = await aws_service.get_llm_output_from_s3(filename)
            if result:
                print(f"   ✅ Successfully retrieved LLM output")
                print(f"   Keys: {list(result.keys()) if isinstance(result, dict) else type(result)}")
            else:
                print(f"   ❌ Failed to retrieve LLM output despite existence check")
        else:
            print(f"   ❌ No LLM output found")

if __name__ == "__main__":
    asyncio.run(debug_llm_check())
