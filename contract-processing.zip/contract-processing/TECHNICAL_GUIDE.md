# Contract Processing System - Technical Implementation Guide

## Table of Contents
1. [Development Setup](#development-setup)
2. [Code Structure](#code-structure)
3. [Key Classes and Methods](#key-classes-and-methods)
4. [Configuration Management](#configuration-management)
5. [Testing Strategy](#testing-strategy)
6. [Deployment Guide](#deployment-guide)
7. [Performance Optimization](#performance-optimization)
8. [Monitoring and Logging](#monitoring-and-logging)

---

## Development Setup

### Prerequisites
```bash
# Python 3.8+
python --version

# AWS CLI configured with proper credentials
aws configure list

# Required environment variables
export AWS_PROFILE=GENAI-POC_AWSAdministratorAccess
export AWS_REGION=us-east-1
```

### Quick Start
```powershell
# Clone and setup
cd C:\git\playground\contract-processing
python -m venv .venv
.venv\Scripts\Activate.ps1

# Install dependencies
pip install -r requirements.txt

# Start the server
python -m uvicorn app.main:app --reload --port 8000
```

### Project Structure
```
contract-processing/
├── app/                          # Main application code
│   ├── __init__.py
│   ├── main.py                   # FastAPI application
│   ├── models/                   # Data models
│   │   ├── __init__.py
│   │   └── processing_models.py  # Pydantic models
│   ├── services/                 # Business logic
│   │   ├── __init__.py
│   │   ├── aws_service.py        # AWS integration
│   │   └── contract_processor.py # Main processing logic
│   └── utils/                    # Utility functions
│       ├── __init__.py
│       ├── file_utils.py         # File operations
│       └── pdf_processor.py      # PDF handling
├── data/                         # Data directory
│   ├── sample_contracts/         # Input PDF files
│   ├── output/                   # Generated reports
│   └── state/                    # Job state files
├── logs/                         # Log files
├── requirements.txt              # Python dependencies
└── .env                          # Environment variables
```

---

## Code Structure

### Core Application (`app/main.py`)
```python
from fastapi import FastAPI, UploadFile, BackgroundTasks
from app.services.contract_processor import ContractProcessor

app = FastAPI(title="Contract Processing API")

@app.post("/contracts/process")
async def process_contracts(background_tasks: BackgroundTasks):
    """
    Main endpoint for contract processing.
    Starts background job and returns job ID.
    """
    processor = ContractProcessor()
    job_id = await processor.start_processing()
    return {"job_id": job_id, "status": "started"}
```

### Data Models (`app/models/processing_models.py`)
```python
from pydantic import BaseModel
from enum import Enum
from typing import Optional
from datetime import datetime

class ProcessingStatus(str, Enum):
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"

class ContractAnalysisResult(BaseModel):
    filename: str
    counterparty: Optional[str]
    contractTitle: Optional[str]
    contractDate: Optional[str]
    offshoreDataProvision: Optional[str]
    dataSubject: Optional[str]
    restrictionDirection: Optional[str]
    complianceRequirements: Optional[str]
    analysisNotes: Optional[str]
    processing_time_seconds: Optional[float]
    timestamp: datetime = datetime.now()
    
class JobState(BaseModel):
    job_id: str
    status: ProcessingStatus
    total_files: int
    processed_files: int
    failed_files: int
    start_time: datetime
    end_time: Optional[datetime]
    results: List[ContractAnalysisResult] = []
```

---

## Key Classes and Methods

### ContractProcessor Class

#### Main Processing Method
```python
async def _process_job(self, job_id: str, files_to_process: List[str]):
    """
    Core processing logic with intelligent caching and deduplication.
    
    Key Features:
    - Creates one result placeholder per input file
    - Loads existing results from S3 for skipped files
    - Updates results as files are processed
    - Ensures exactly one result per input file
    """
    
    # Initialize results dictionary for ALL input files
    all_input_files = list(Path("data/sample_contracts").glob("*.pdf"))
    results_by_filename = {}
    
    for file_path in all_input_files:
        filename = Path(file_path).name
        results_by_filename[filename] = self._create_placeholder_result(filename)
    
    # Load existing results for skipped files
    for file_path in skipped_files:
        filename = Path(file_path).name
        result = await self.aws_service.get_llm_output_from_s3(filename)
        if result:
            results_by_filename[filename] = self._convert_to_result_model(result, filename)
    
    # Process remaining files
    for file_path in files_to_process:
        result = await self._process_single_file(file_path)
        results_by_filename[result.filename] = result
    
    # Generate final output
    final_results = list(results_by_filename.values())
    await self._generate_output_files(final_results, job_id)
```

#### File Status Determination
```python
async def _determine_file_status(self, file_path: Path) -> Tuple[str, str]:
    """
    Determines what processing is needed for each file.
    
    Returns:
        Tuple[status, reason] where status is one of:
        - "skip": Both Textract and LLM outputs exist
        - "llm_only": Only LLM analysis needed
        - "textract_only": Only text extraction needed  
        - "full": Both text extraction and analysis needed
    """
    filename = file_path.name
    base_filename = file_path.stem
    
    # Check S3 for existing outputs
    textract_exists = await self.aws_service.check_textract_output_exists(filename)
    llm_exists = await self.aws_service.check_llm_output_exists(base_filename)
    
    if textract_exists and llm_exists:
        return "skip", "Both Textract and LLM outputs exist"
    elif textract_exists and not llm_exists:
        return "llm_only", "Textract output exists, LLM analysis needed"
    elif not textract_exists and llm_exists:
        return "textract_only", "LLM output exists, Textract extraction needed"
    else:
        return "full", "Both Textract and LLM processing needed"
```

### AWSService Class

#### S3 Caching Logic
```python
async def get_llm_output_from_s3(self, filename: str) -> Optional[Dict]:
    """
    Retrieves cached LLM analysis from S3.
    
    Key Points:
    - Uses base filename (without extension) for consistency
    - Handles filename with special characters properly
    - Returns structured JSON result or None if not found
    """
    base_filename = Path(filename).stem
    
    try:
        # List objects with prefix to find the most recent
        response = self.s3_client.list_objects_v2(
            Bucket=self.bucket_name,
            Prefix=f"llm/output/{base_filename}-"
        )
        
        if 'Contents' not in response:
            return None
            
        # Get the most recent file (sorted by timestamp)
        latest_object = sorted(response['Contents'], 
                             key=lambda x: x['LastModified'])[-1]
        
        # Download and parse JSON
        obj_response = self.s3_client.get_object(
            Bucket=self.bucket_name,
            Key=latest_object['Key']
        )
        
        content = obj_response['Body'].read().decode('utf-8')
        return json.loads(content)
        
    except Exception as e:
        logger.error(f"Error retrieving LLM output from S3: {e}")
        return None
```

#### Fixed Filename Handling
```python
async def save_llm_output_to_s3(self, filename: str, result: Dict) -> bool:
    """
    Saves LLM analysis result to S3.
    
    CRITICAL FIX: Uses base_filename directly instead of double Path().stem
    This prevents filename truncation issues like "(11.16.2021)" → "(11.16"
    """
    try:
        # FIXED: Use base_filename directly, no double Path().stem
        base_filename = Path(filename).stem
        timestamp = int(time.time())
        s3_key = f"llm/output/{base_filename}-{timestamp}.json"
        
        self.s3_client.put_object(
            Bucket=self.bucket_name,
            Key=s3_key,
            Body=json.dumps(result, indent=2),
            ContentType='application/json'
        )
        
        logger.info(f"✅ Saved LLM output to S3: {s3_key}")
        return True
        
    except Exception as e:
        logger.error(f"❌ Error saving LLM output to S3: {e}")
        return False
```

### PDF Processor

#### Textract Integration
```python
async def extract_text_from_pdf(self, file_path: str, 
                               progress_callback=None) -> Optional[str]:
    """
    Extracts text from PDF using AWS Textract.
    
    Features:
    - Supports both sync and async processing
    - Handles multi-page documents
    - Progress reporting for long documents
    - Automatic retry logic for transient errors
    """
    try:
        # Read PDF file
        with open(file_path, 'rb') as pdf_file:
            pdf_bytes = pdf_file.read()
        
        # Use sync processing for smaller files, async for larger
        if len(pdf_bytes) < 5 * 1024 * 1024:  # 5MB threshold
            response = self.textract_client.detect_document_text(
                Document={'Bytes': pdf_bytes}
            )
            return self._extract_text_from_response(response)
        else:
            return await self._process_large_document(pdf_bytes, progress_callback)
            
    except Exception as e:
        logger.error(f"Textract extraction failed: {e}")
        return None
```

---

## Configuration Management

### Environment Configuration
```python
# app/config.py
import os
from typing import Optional

class Settings:
    # AWS Configuration
    AWS_PROFILE: str = os.getenv("AWS_PROFILE", "default")
    AWS_REGION: str = os.getenv("AWS_REGION", "us-east-1")
    AWS_S3_BUCKET: str = os.getenv("AWS_S3_BUCKET", "contract-processing")
    
    # Bedrock Configuration
    BEDROCK_MODEL_ID: str = os.getenv(
        "BEDROCK_MODEL_ID", 
        "anthropic.claude-3-5-sonnet-20240620-v1:0"
    )
    
    # Processing Configuration
    MAX_CONCURRENT_JOBS: int = int(os.getenv("MAX_CONCURRENT_JOBS", "3"))
    TEXTRACT_SYNC_THRESHOLD_MB: int = int(os.getenv("TEXTRACT_SYNC_THRESHOLD_MB", "5"))
    
    # File Paths
    INPUT_DIR: str = os.getenv("INPUT_DIR", "data/sample_contracts")
    OUTPUT_DIR: str = os.getenv("OUTPUT_DIR", "data/output")
    STATE_DIR: str = os.getenv("STATE_DIR", "data/state")
    LOG_DIR: str = os.getenv("LOG_DIR", "logs")

settings = Settings()
```

### Logging Configuration
```python
# app/utils/logging_config.py
import logging
import os
from datetime import datetime

def setup_logging():
    log_dir = "logs"
    os.makedirs(log_dir, exist_ok=True)
    
    log_filename = f"{log_dir}/contract_processing.log"
    
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_filename),
            logging.StreamHandler()  # Console output
        ]
    )
    
    # Set specific log levels for AWS libraries
    logging.getLogger('boto3').setLevel(logging.WARNING)
    logging.getLogger('botocore').setLevel(logging.WARNING)
    logging.getLogger('urllib3').setLevel(logging.WARNING)
```

---

## Testing Strategy

### Unit Tests Structure
```python
# tests/test_aws_service.py
import pytest
from unittest.mock import Mock, patch
from app.services.aws_service import AWSService

class TestAWSService:
    @pytest.fixture
    def aws_service(self):
        return AWSService()
    
    @patch('boto3.client')
    async def test_get_llm_output_from_s3_success(self, mock_boto, aws_service):
        # Mock S3 response
        mock_s3 = Mock()
        mock_boto.return_value = mock_s3
        mock_s3.list_objects_v2.return_value = {
            'Contents': [{'Key': 'llm/output/test-123.json', 'LastModified': datetime.now()}]
        }
        mock_s3.get_object.return_value = {
            'Body': Mock(read=lambda: b'{"test": "data"}')
        }
        
        result = await aws_service.get_llm_output_from_s3("test.pdf")
        assert result == {"test": "data"}
    
    async def test_filename_processing(self, aws_service):
        # Test the critical filename handling fix
        filename = "Bank of America Agreement (11.16.2021).pdf"
        base_filename = Path(filename).stem
        
        # Should NOT truncate the filename
        assert base_filename == "Bank of America Agreement (11.16.2021)"
        assert base_filename != "Bank of America Agreement (11.16"
```

### Integration Tests
```python
# tests/test_integration.py
import pytest
import tempfile
from pathlib import Path
from app.services.contract_processor import ContractProcessor

class TestIntegration:
    @pytest.mark.asyncio
    async def test_end_to_end_processing(self):
        """Test complete processing workflow with sample files."""
        processor = ContractProcessor()
        
        # Use a small subset of files for testing
        test_files = ["test_contract1.pdf", "test_contract2.pdf"]
        
        job_id = await processor.start_processing(file_filter=test_files)
        
        # Wait for completion
        while True:
            status = await processor.get_job_status(job_id)
            if status.status in [ProcessingStatus.COMPLETED, ProcessingStatus.FAILED]:
                break
            await asyncio.sleep(1)
        
        assert status.status == ProcessingStatus.COMPLETED
        assert len(status.results) == len(test_files)
```

### Performance Tests
```python
# tests/test_performance.py
import time
import pytest
from app.services.contract_processor import ContractProcessor

class TestPerformance:
    @pytest.mark.asyncio
    async def test_caching_performance(self):
        """Verify that cached files are processed quickly."""
        processor = ContractProcessor()
        
        # First run (will cache results)
        start_time = time.time()
        job_id1 = await processor.start_processing()
        await processor.wait_for_completion(job_id1)
        first_run_time = time.time() - start_time
        
        # Second run (should use cache)
        start_time = time.time()
        job_id2 = await processor.start_processing()
        await processor.wait_for_completion(job_id2)
        second_run_time = time.time() - start_time
        
        # Second run should be significantly faster
        assert second_run_time < first_run_time * 0.3  # At least 70% faster
```

---

## Deployment Guide

### Local Development
```powershell
# Setup environment
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt

# Configure AWS credentials
aws configure set profile.GENAI-POC_AWSAdministratorAccess.region us-east-1
aws configure set profile.GENAI-POC_AWSAdministratorAccess.aws_access_key_id YOUR_KEY
aws configure set profile.GENAI-POC_AWSAdministratorAccess.aws_secret_access_key YOUR_SECRET

# Start development server
python -m uvicorn app.main:app --reload --port 8000
```

### Production Deployment (Docker)
```dockerfile
# Dockerfile
FROM python:3.9-slim

WORKDIR /app

# Install system dependencies
RUN apt-get update && apt-get install -y \
    gcc \
    && rm -rf /var/lib/apt/lists/*

# Install Python dependencies
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Copy application code
COPY app/ ./app/
COPY data/ ./data/

# Set environment variables
ENV AWS_REGION=us-east-1
ENV LOG_LEVEL=INFO

# Expose port
EXPOSE 8000

# Start application
CMD ["uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", "8000"]
```

### AWS ECS Deployment
```yaml
# docker-compose.yml
version: '3.8'
services:
  contract-processor:
    build: .
    ports:
      - "8000:8000"
    environment:
      - AWS_REGION=us-east-1
      - AWS_S3_BUCKET=contract-processing
    volumes:
      - ./logs:/app/logs
      - ./data/output:/app/data/output
    deploy:
      resources:
        limits:
          cpus: '2.0'
          memory: 4G
        reservations:
          cpus: '1.0'
          memory: 2G
```

---

## Performance Optimization

### Memory Management
```python
# Process files in batches to manage memory usage
async def process_files_in_batches(self, files: List[str], batch_size: int = 5):
    """Process files in batches to manage memory usage."""
    for i in range(0, len(files), batch_size):
        batch = files[i:i + batch_size]
        await asyncio.gather(*[self._process_single_file(f) for f in batch])
        
        # Force garbage collection between batches
        import gc
        gc.collect()
```

### AWS Service Optimization
```python
# Use connection pooling for S3 operations
from botocore.config import Config

config = Config(
    retries={'max_attempts': 3, 'mode': 'adaptive'},
    max_pool_connections=50
)

self.s3_client = boto3.client('s3', config=config)
```

### Caching Strategy
```python
# Implement local caching for frequently accessed S3 objects
from functools import lru_cache

@lru_cache(maxsize=100)
async def get_cached_llm_output(self, filename: str):
    """Local cache for LLM outputs to reduce S3 calls."""
    return await self.get_llm_output_from_s3(filename)
```

---

## Monitoring and Logging

### Comprehensive Logging
```python
# Add structured logging throughout the application
import structlog

logger = structlog.get_logger()

async def _process_single_file(self, file_path: str):
    start_time = time.time()
    filename = Path(file_path).name
    
    logger.info("processing_started", 
                filename=filename, 
                file_size=os.path.getsize(file_path))
    
    try:
        result = await self._do_processing(file_path)
        processing_time = time.time() - start_time
        
        logger.info("processing_completed",
                    filename=filename,
                    processing_time=processing_time,
                    success=True)
        
        return result
        
    except Exception as e:
        processing_time = time.time() - start_time
        
        logger.error("processing_failed",
                     filename=filename,
                     processing_time=processing_time,
                     error=str(e),
                     success=False)
        raise
```

### Health Check Endpoints
```python
# Add health check endpoints for monitoring
@app.get("/health")
async def health_check():
    """Basic health check endpoint."""
    return {"status": "healthy", "timestamp": datetime.now()}

@app.get("/health/detailed")
async def detailed_health_check():
    """Detailed health check including AWS service connectivity."""
    health_status = {
        "status": "healthy",
        "timestamp": datetime.now(),
        "services": {}
    }
    
    # Check S3 connectivity
    try:
        aws_service = AWSService()
        aws_service.s3_client.head_bucket(Bucket=aws_service.bucket_name)
        health_status["services"]["s3"] = "healthy"
    except Exception as e:
        health_status["services"]["s3"] = f"unhealthy: {e}"
        health_status["status"] = "degraded"
    
    # Check Bedrock connectivity
    try:
        await aws_service._test_bedrock_connection()
        health_status["services"]["bedrock"] = "healthy"
    except Exception as e:
        health_status["services"]["bedrock"] = f"unhealthy: {e}"
        health_status["status"] = "degraded"
    
    return health_status
```

### Metrics Collection
```python
# Add basic metrics collection
class MetricsCollector:
    def __init__(self):
        self.processing_times = []
        self.error_counts = defaultdict(int)
        self.file_counts = {"processed": 0, "skipped": 0, "failed": 0}
    
    def record_processing_time(self, filename: str, time_seconds: float):
        self.processing_times.append(time_seconds)
    
    def record_error(self, error_type: str):
        self.error_counts[error_type] += 1
    
    def get_summary(self):
        return {
            "avg_processing_time": sum(self.processing_times) / len(self.processing_times) if self.processing_times else 0,
            "total_files_processed": self.file_counts["processed"],
            "total_errors": sum(self.error_counts.values()),
            "error_breakdown": dict(self.error_counts)
        }

# Global metrics instance
metrics = MetricsCollector()

@app.get("/metrics")
async def get_metrics():
    """Endpoint for collecting application metrics."""
    return metrics.get_summary()
```

---

## Troubleshooting Guide

### Common Development Issues

1. **AWS Credentials Not Found**
   ```bash
   Error: NoCredentialsError: Unable to locate credentials
   
   Solution:
   aws configure set profile.GENAI-POC_AWSAdministratorAccess.region us-east-1
   aws configure set profile.GENAI-POC_AWSAdministratorAccess.aws_access_key_id YOUR_KEY
   ```

2. **S3 Permission Denied**
   ```bash
   Error: An error occurred (AccessDenied) when calling the GetObject operation
   
   Solution:
   - Verify AWS profile has S3 access permissions
   - Check bucket name is correct in environment variables
   - Ensure bucket exists and is in the correct region
   ```

3. **Textract/Bedrock Service Limits**
   ```bash
   Error: ThrottlingException: Rate exceeded
   
   Solution:
   - Implement exponential backoff retry logic
   - Reduce concurrent processing batch size
   - Contact AWS support for quota increases
   ```

### Debugging Commands
```powershell
# Test AWS connectivity
python -c "
import boto3
session = boto3.Session(profile_name='GENAI-POC_AWSAdministratorAccess')
s3 = session.client('s3')
print('S3 buckets:', [b['Name'] for b in s3.list_buckets()['Buckets']])
"

# Test LLM output retrieval
python -c "
import asyncio
from app.services.aws_service import AWSService
async def test():
    aws = AWSService()
    result = await aws.get_llm_output_from_s3('test.pdf')
    print('Result:', result is not None)
asyncio.run(test())
"

# Check file processing status
python -c "
from pathlib import Path
files = list(Path('data/sample_contracts').glob('*.pdf'))
print(f'Found {len(files)} PDF files')
for f in files[:5]:
    print(f'  {f.name}')
"
```

---

*This technical guide was created on August 11, 2025. For the latest updates and implementation details, refer to the source code and commit history.*
